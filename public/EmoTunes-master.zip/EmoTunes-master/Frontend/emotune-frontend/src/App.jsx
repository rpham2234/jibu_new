import React from 'react'
import Home from './pages/home'
import Tunes from './pages/tunes'
import SignUp from './pages/Signup'
import HistoryPage from './pages/HistoryPage'
import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import About from './pages/About'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/tunes" element={<Tunes />} />
        <Route path="/signup" element={<SignUp/>} />
        <Route path="/history" element={<HistoryPage />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </Router>
  )
}

export default App;

