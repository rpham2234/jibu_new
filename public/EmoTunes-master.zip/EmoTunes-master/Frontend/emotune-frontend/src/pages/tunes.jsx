import React from 'react'
import CamInterface from '../components/camInterface'
import Navbar from '../components/Navbar'

const Tunes = () => {
  return (
    <div>
      <Navbar />
      <CamInterface />
    </div>
  )
}

export default Tunes
