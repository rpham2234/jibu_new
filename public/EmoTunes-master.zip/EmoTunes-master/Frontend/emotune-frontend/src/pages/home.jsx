import React from 'react';
import { Link } from 'react-router-dom';
import SunScene from '../components/SunScene';
import Navbar from '../components/Navbar';
import Foreground from '../components/Foreground';
import SunsetScene from '../components/SunsetScene';
import SignUp from './Signup';

const Home = () => {
  return (
    <div className="relative w-full h-screen overflow-hidden">
      {/*Navbar Added to be at the top of the page*/}
      <div>
        <Navbar />
      </div>
      {/* Background scene */}
      <div className="absolute inset-0 z-0">
        <SunScene />
      </div>

      {/* <div className='absolute inset-0 z-0'>
        <SunsetScene />
      </div> */}
      {/* Foreground content */}
      <div className='relative z-10 flex flex-col items-center justify-center text-center mt-24 space-y-6'>
        <Foreground />
      </div>
    </div>
  );
};

export default Home;
