import React from "react";
import AnimatedSunPointer from "../components/AnimatedSunPointer";
import SignupBox from "../components/SignupBox";
import Navbar from "../components/Navbar";

const SignUp = () => {
    return (
        <div className="w-full h-screen flex">
            <Navbar />
            <div id="yellow-side" className="bg-yellow-300 w-1/2 h-full relative overflow-hidden">
                <AnimatedSunPointer targetId="yellow-side"/>
            </div>

            <div className="w-1/2 h-full bg-white flex items-center justify-center">
                <SignupBox />
            </div>
            
        </div>
    )
}

export default SignUp;
