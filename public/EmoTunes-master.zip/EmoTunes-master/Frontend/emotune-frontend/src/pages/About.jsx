import React from 'react';
import { motion } from 'framer-motion';
import LogoGrid from '../components/LogoGrid';
import { FaCamera, FaSpotify, FaHeart, FaLock, FaMusic } from 'react-icons/fa';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import TeamSection from '../components/TeamSection';

const features = [
  {
    icon: <FaCamera className="text-3xl text-indigo-600" />,
    title: 'Real-time Emotion Detection',
    description: 'Capture your emotional state via webcam using AI.'
  },
  {
    icon: <FaSpotify className="text-3xl text-green-500" />,
    title: 'Spotify Music Recommendations',
    description: 'Instantly get mood-based tracks from Spotify.'
  },
  {
    icon: <FaHeart className="text-3xl text-pink-500" />,
    title: 'Like & Dislike Tracking',
    description: 'Keep a history of what you liked and skipped.'
  },
  {
    icon: <FaLock className="text-3xl text-yellow-600" />,
    title: 'JWT Authentication',
    description: 'Secure login with JWT tokens for privacy.'
  }
];


const About = () => {
  return (
    <div className="px-6 py-12 max-w-5xl mx-auto text-black space-y-16 mt-20">
        <Navbar />

      {/* Hero Section */}
      <section className="text-center space-y-6">
        <motion.h1
          initial={{ opacity: 0, y: -40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-[5rem] font-extrabold leading-none tracking-tight"
        >
          Emo<span className="text-black text-[5rem] font-black">Tune</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="text-lg font-light max-w-3xl mx-auto text-justify"
        >
          <span className="text-xl font-semibold">EmoTune</span> is an AI-powered web application that detects your emotional state using your webcam and recommends music tailored to your mood. Whether you're feeling joyful, sad, calm, or energized, EmoTune tunes into your vibe and plays the right songs to match.
          <br /><br />
          Built with a focus on emotional well-being, expressive UI, and seamless integration with Spotify, EmoTune blends emotion detection technology with musical therapy to enhance your everyday experience.
        </motion.p>
      </section>

      {/* Features Section */}
<section>
  <motion.h2
    initial={{ opacity: 0, y: -20 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6 }}
    viewport={{ once: true }}
    className="text-3xl font-semibold mb-10 text-center"
  >
    Features
  </motion.h2>

  <div className="grid sm:grid-cols-2 gap-6">
    {features.map((feature, index) => (
      <motion.div
        key={index}
        className="p-6 bg-white rounded-xl shadow-lg flex items-start space-x-4 hover:shadow-xl transition-shadow duration-300"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: index * 0.1 }}
        viewport={{ once: true }}
      >
        <div>{feature.icon}</div>
        <div>
          <h3 className="font-semibold text-lg mb-1">{feature.title}</h3>
          <p className="text-sm text-gray-600">{feature.description}</p>
        </div>
      </motion.div>
    ))}
  </div>
</section>

      {/* Tech Stack Section */}
      <section>
        <h2 className="text-3xl font-semibold mb-6 text-center">Tech Stack</h2>
        <LogoGrid />
      </section>

      {/* Our Story Section */}
<section className="relative overflow-hidden rounded-xl py-16 px-6 bg-gradient-to-br from-white/70 to-yellow-100/40 shadow-md">

  {/* Floating music note */}
  <FaMusic className="absolute text-yellow-300 text-8xl opacity-20 -top-6 -left-6 animate-pulse pointer-events-none" />

  <motion.h2
    initial={{ opacity: 0, y: -20 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6 }}
    viewport={{ once: true }}
    className="text-3xl font-semibold mb-6 text-center text-black"
  >
    Our Story
  </motion.h2>

  <motion.blockquote
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.8 }}
    viewport={{ once: true }}
    className="text-base font-light max-w-3xl mx-auto text-center italic text-gray-700"
  >
    “EmoTune was born from a curiosity about the intersection of emotion and music. We wanted to create a tool that responds to how you feel in real-time, using AI to deliver a soundtrack that matches your mood. What started as a side project has grown into a passion for building emotionally intelligent interfaces — one note at a time.”
  </motion.blockquote>

  <motion.div
    initial={{ width: 0 }}
    whileInView={{ width: "50%" }}
    transition={{ duration: 0.6, delay: 0.3 }}
    viewport={{ once: true }}
    className="h-[2px] bg-black mt-6 mx-auto"
  />
</section>
<section>
    <TeamSection />
</section>
<section>
    <Footer />
</section>
    </div>
  );
};

export default About;
