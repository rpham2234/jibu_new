import React, { useEffect, useState } from "react";
import axios from "../axiosConfig";
import Navbar from "../components/Navbar";

const HistoryPage = () => {
  const [likedSongs, setLikedSongs] = useState([]);
  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchLikedSongs = async () => {
    try {
      const response = await axios.get("/recommend/map", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      setLikedSongs(response.data);
    } catch (err) {
      console.error("Failed to fetch liked songs:", err);
    }
  };

  const fetchPlaylists = async () => {
    const userId = localStorage.getItem("user_id");
    if (!userId) {
      console.log("No user_id found in localStorage");
      return;
    }

    setLoading(true);
    try {
      const response = await axios.get(`https://emotune-jik6.onrender.com/api/playlists/user/${userId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
      });
      console.log("Fetched playlists:", response.data);
      setPlaylists(response.data);
    } catch (err) {
      console.error("Failed to fetch playlists:", err);
      setPlaylists([]);
    } finally {
      setLoading(false);
    }
  };

  const refreshPlaylists = () => {
    fetchPlaylists();
  };

  useEffect(() => {
    fetchLikedSongs();
    fetchPlaylists();
  }, []);

  return (
    <div className="min-h-screen bg-yellow-300 p-6 sm:p-10 text-white flex flex-col items-center">
      <Navbar />
      <h1 className="text-4xl font-bold mb-8 flex items-center mt-20 text-black">
        <span role="img" aria-label="music" className="mr-2">🎵</span>
        Your Liked Songs
      </h1>

      {likedSongs.length === 0 ? (
        <p className="text-lg text-black">No liked songs yet.</p>
      ) : (
        <ul className="w-full max-w-xl space-y-3">
          {likedSongs.map((song, index) => (
            <li
              key={index}
              className="bg-gray-900 hover:bg-gray-800 text-white px-5 py-3 rounded-lg transition duration-200 shadow-md"
            >
              💿 {song}
            </li>
          ))}
        </ul>
      )}

      <div className="w-full max-w-xl mt-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-black">Your Playlists</h2>
          <button
            onClick={refreshPlaylists}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50"
          >
            {loading ? 'Refreshing...' : 'Refresh'}
          </button>
        </div>
        
        {loading ? (
          <p className="text-black">Loading playlists...</p>
        ) : playlists.length === 0 ? (
          <div className="bg-gray-100 rounded-lg p-4 text-center">
            <p className="text-black">No playlists found.</p>
            <p className="text-gray-600 text-sm mt-2">
              Create a playlist by clicking "Add to Playlist" on any song recommendation!
            </p>
          </div>
        ) : (
          playlists.map((pl) => (
            <div key={pl.id} className="mb-4 bg-gray-100 rounded-lg p-4 text-black shadow-md">
              <div className="flex items-center justify-between mb-2">
                <div className="font-semibold text-lg">🎶 {pl.name}</div>
                <div className="text-sm text-gray-600">
                  {pl.songIds?.length || 0} songs
                </div>
              </div>
              {(!pl.songIds || pl.songIds.length === 0) ? (
                <div className="pl-2 text-gray-500 text-sm italic">No songs in this playlist.</div>
              ) : (
                <ul className="mt-2">
                  {pl.songIds.map((sid, idx) => (
                    <li key={idx} className="pl-4 py-1 text-sm border-l-2 border-blue-300">
                      🎵 {sid}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default HistoryPage;
