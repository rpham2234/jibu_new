// src/components/Birds.jsx
import React from 'react'
import Bird from "../assets/bird.svg"
import { motion } from "framer-motion";

const Birds = () => (
<div>
    {/* left birds */}
    <motion.img
    src={Bird}
    alt="bird"
    className="absolute  w-[100px]"
    initial={{ opacity: 0, x: -320 , y:0}}
    animate={{ opacity: 1, x: 500 , y: 400}}
    transition={{ duration: 1.6 }}
  />
    <motion.img
    src={Bird}
    alt="bird"
    className="absolute  w-[100px]"
    initial={{ opacity: 0, x: -320 , y:0}}
    animate={{ opacity: 1, x: 400 , y: 350}}
    transition={{ duration: 1.6 }}
  />
    {/* right birds */}
      <motion.img
    src={Bird}
    alt="bird"
    className="absolute  w-[50px]"
    initial={{ opacity: 0, x: 1500 , y:0}}
    animate={{ opacity: 1, x: 1000 , y: 200}}
    transition={{ duration: 1.6 }}
  />
    <motion.img
    src={Bird}
    alt="bird"
    className="absolute  w-[50px]"
    initial={{ opacity: 0, x: 1500 , y:0}}
    animate={{ opacity: 1, x: 1050 , y: 180}}
    transition={{ duration: 1.6 }}
  />
</div>

)

export default Birds
