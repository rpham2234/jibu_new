import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();
  const [loggedIn, setLoggedIn] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [username, setUsername] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    const storedUsername = localStorage.getItem("username");
    if (token && storedUsername) {
      setLoggedIn(true);
      setUsername(storedUsername);
    }
  }, []);

  const handleSignOut = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    setLoggedIn(false);
    setDropdownOpen(false);
    navigate("/signup");
  };

  return (
    <motion.div
      initial={{
        top: "100vh",
        borderRadius: "9999px",
        scale: 1,
        width: "60px",
        height: "60px"
      }}
      animate={{
        top: "25px",
        width: "min(90%, 600px)",
        height: "60px",
        borderRadius: "2rem"
      }}
      transition={{
        top: { duration: 1.2, ease: "easeInOut", delay: 0 },
        width: { duration: 0.8, ease: "easeInOut", delay: 1.2 },
        height: { duration: 0.8, ease: "easeInOut", delay: 1.2 },
        borderRadius: { duration: 0.8, ease: "easeInOut", delay: 1.2 }
      }}
      className="fixed left-1/2 -translate-x-1/2 bg-white shadow-lg z-[80] flex justify-around items-center text-black font-semibold border-2 border-black"
    >
      <motion.span
        className="px-4 cursor-pointer"
        onClick={() => navigate("/")}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 0.6 }}
      >
        Home
      </motion.span>

      <motion.span
        className="px-4 cursor-pointer"
        onClick={() => navigate("/about")}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 0.6 }}
      >
        About
      </motion.span>

      <motion.span
        className="px-4 cursor-pointer"
        onClick={() => navigate("/history")}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 0.6 }}
      >
        History
      </motion.span>

      {!loggedIn ? (
        <motion.span
          className="px-4 cursor-pointer"
          onClick={() => navigate("/signup")}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.0, duration: 0.6 }}
        >
          Sign Up
        </motion.span>
      ) : (
        <div className="relative px-4">
          <motion.span
            className="cursor-pointer"
            onClick={() => setDropdownOpen(!dropdownOpen)}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.0, duration: 0.6 }}
          >
            {username}
          </motion.span>

          {dropdownOpen && (
            <div className="absolute right-0 mt-2 bg-white border-2 rounded-full shadow px-4 py-2 text-sm">
              <span className="cursor-pointer" onClick={handleSignOut}>
                Sign Out
              </span>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
};

export default Navbar;
