import React from 'react';
import Rainbow from './Rainbow';
import Sun from './Sun';
import Clouds from './Clouds';
import Cloud5 from "../assets/Cloud5.svg";
import Star from "../assets/Star.svg";

const SunScene = () => {
  return (
    <div className="relative w-full h-full bg-yellow-300 overflow-hidden">
      <Rainbow/>
      <Sun/>
      {/* Static clouds and star */}
      <img src={Cloud5} className="absolute top-[180px] right-[250px] w-[250px] drop-shadow-xl z-[60]"/>
      <img src={Star} className="absolute top-[350px] left-[350px] w-[100px] h-[100px]  z-[60]"/>
      <Clouds/>
    </div>
  );
};

export default SunScene;
