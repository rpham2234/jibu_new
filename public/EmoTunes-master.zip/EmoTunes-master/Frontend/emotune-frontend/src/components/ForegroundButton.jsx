import React from 'react'
import { Link } from 'react-router-dom'

const ForegroundButton = () => {
  return (
    <div>
        <Link to="/tunes">
            <div className='w-[120px] h-[50px] bg-white rounded-full border-1 border-black hover:bg-black'>
                <button className="w-[118px] h-[45px] px-6 py-2 border-2 bg-black text-white border-black rounded-full hover:bg-white hover:text-black transition">
                    Tune In..
                </button>
            </div>
        </Link>
    </div>
  )
}

export default ForegroundButton