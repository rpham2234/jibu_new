import React, { useState } from 'react';
import { motion } from 'framer-motion';
import SpringLogo from '../assets/springbootsvg.png';
import TailwindLogo from '../assets/tailwind-css-logo-vector.png';
import SpotifyLogo from '../assets/spotify.png';
import GeminiLogo from '../assets/GeminiLogo.png';
import GitLogo from '../assets/gitLogo.png';
import MotionLogo from '../assets/framerLogo.png'
import ReactLogo from '../assets/react.svg'

const row1 = [
  { src: SpringLogo, label: 'Spring Boot' },
  { src: TailwindLogo, label: 'Tailwind CSS' },
  { src: SpotifyLogo, label: 'Spotify API' },
  { src: GeminiLogo, label: 'Gemini API' }
];

const row2 = [
  { src: GitLogo, label: 'Git' },
  { src: MotionLogo, label: 'Framer Motion' },
  { src: ReactLogo, label: 'React' }
];

const LogoGrid = () => {
  const [hovered, setHovered] = useState(null);

  return (
    <section className="py-12">
      
      {/* First Row: 4 Logos */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-8 items-center justify-items-center mb-8">
        {row1.map((logo, i) => (
          <motion.div
            key={i}
            className="flex flex-col items-center cursor-pointer"
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
            whileHover={{ y: -8 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <img src={logo.src} alt={logo.label} className="w-16 h-16 object-contain" />
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: hovered === i ? 1 : 0 }}
              className="text-sm mt-2 font-medium"
            >
              {logo.label}
            </motion.span>
          </motion.div>
        ))}
      </div>

      {/* Second Row: 3 Logos, Centered */}
      <div className="flex justify-center gap-12 items-center">
        {row2.map((logo, i) => (
          <motion.div
            key={i + row1.length}
            className="flex flex-col items-center cursor-pointer"
            onMouseEnter={() => setHovered(i + row1.length)}
            onMouseLeave={() => setHovered(null)}
            whileHover={{ y: -8 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <img src={logo.src} alt={logo.label} className="w-16 h-16 object-contain" />
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: hovered === i + row1.length ? 1 : 0 }}
              className="text-sm mt-2 font-medium"
            >
              {logo.label}
            </motion.span>
          </motion.div>
        ))}
      </div>
      
    </section>
  );
};

export default LogoGrid;
