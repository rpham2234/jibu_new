import React from "react";
import { motion } from "framer-motion";

const barCount = 9;

const AnimatedTunes = () => {
    return (
        <div className="flex items-end gap-2 h-[100px] w-auto">
            {Array.from({ length: barCount }).map((_, i) => {
            const randomScale = (Math.random() * 0.8 + 0.6).toFixed(2); 
            const baseHeight = Math.floor(Math.random() * 40 + 40);

            return (
                <motion.div
                    key={i}
                    className="bg-black rounded-full w-[10px]"
                    style={{ 
                        height: `${baseHeight}px`, 
                        transformOrigin: "center center" 
                    }}

                    animate={{
                        scaleY: [1, randomScale, 1],
                    }}

                    transition={{
                        duration: 1.2 + Math.random(),
                        repeat: Infinity,
                        repeatType: "reverse",
                        ease: "easeInOut",
                        delay: i * 0.1,
                    }}
                />
            );
            })}
        </div>
    )
}

export default AnimatedTunes;
