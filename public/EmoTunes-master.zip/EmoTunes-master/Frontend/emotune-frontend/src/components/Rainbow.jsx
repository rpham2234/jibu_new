import React from "react";
import { motion, easeOut } from "framer-motion";

const Rainbow = () => {
    return (
        <>
            <motion.div
                initial={{ rotateZ: 180 }}
                animate={{ rotateZ: 0 }}
                transition={{ duration: 2.8, ease: easeOut }}
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-pink-300 rounded-t-full z-10"
                style={{ transformOrigin: 'bottom center' }}
            />
            <motion.div
                initial={{ rotateZ: 180 }}
                animate={{ rotateZ: 0 }}
                transition={{ duration: 2.4, ease: easeOut }}
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-blue-400 rounded-t-full z-20"
                style={{ transformOrigin: 'bottom center' }}
            />
            <motion.div
                initial={{ rotateZ: 180 }}
                animate={{ rotateZ: 0 }}
                transition={{ duration: 2, ease: easeOut }}
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-green-600 rounded-t-full z-30"
                style={{ transformOrigin: 'bottom center' }}
            />
        </>
    )
}

export default Rainbow;
