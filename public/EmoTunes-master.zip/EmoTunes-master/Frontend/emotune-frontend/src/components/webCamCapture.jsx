import React, { useRef, useState } from 'react';
import SongCard from './SongCard';
import { motion, AnimatePresence } from 'framer-motion';
import Clouds from './Clouds';
import PlaylistModal from './PlaylistModal';

const WebcamCapture = () => {
	const videoRef = useRef(null);
	const canvasRef = useRef(null);
	const [stream, setStream] = useState(null);
	const [capturedImage, setCapturedImage] = useState(null);
	const [emotion, setEmotion] = useState('');
	const [songs, setSongs] = useState([]);
	const [loading, setLoading] = useState(false);
	const [showVideo, setVideo] = useState(false);
	const [videoReady, setVideoReady] = useState(false);
	const [modalOpen, setModalOpen] = useState(false);
	const [currentSong, setCurrentSong] = useState(null);
	const userId = localStorage.getItem("user_id");

	function openAddToPlaylistModal(song) {
		setCurrentSong(song);
		setModalOpen(true);
	}

	const startWebcam = async () => {
		try {
			setVideoReady(false);
			const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
			videoRef.current.srcObject = mediaStream;
			setStream(mediaStream);
		} catch (err) {
			console.error("Webcam access denied:", err);
			alert("Could not access webcam.");
		}
	};

	const stopWebcam = () => {
		if (stream) stream.getTracks().forEach(track => track.stop());
		if (videoRef.current) {
			videoRef.current.pause();
			videoRef.current.srcObject = null;
		}
		setStream(null);
	};

	const captureImage = () => {
		const canvas = canvasRef.current;
		const video = videoRef.current;

		if (!videoReady) {
			alert("Video not ready. Please wait a moment.");
			return;
		}

		if (canvas && video && video.videoWidth > 0 && video.videoHeight > 0) {
			canvas.width = video.videoWidth;
			canvas.height = video.videoHeight;
			const ctx = canvas.getContext('2d');
			ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
			const imageData = canvas.toDataURL('image/png');
			setCapturedImage(imageData);
			analyzeEmotion(imageData);
		}
	};

	const analyzeEmotion = async (imageData) => {
		setLoading(true);
		setEmotion('');
		setSongs([]);

		try {
			const blob = await (await fetch(imageData)).blob();
			const formData = new FormData();
			formData.append("image", blob, "capture.png");

			const token = localStorage.getItem("token");

			const res = await fetch("https://emotune-jik6.onrender.com/emotion/detect", {
				method: 'POST',
				headers: {
					Authorization: `Bearer ${token}`
				},
				body: formData
			});

			if (!res.ok) throw new Error(`API returned status ${res.status}`);

			const text = await res.text();
			if (!text) throw new Error("Empty response body from /emotion/detect");

			const data = JSON.parse(text);
			setEmotion(data.emotion);
			fetchSongs(data.emotion);
		} catch (error) {
			console.error('Error detecting emotion:', error);
		} finally {
			setLoading(false);
		}
	};

	const fetchSongs = async (emotion) => {
		try {
			const token = localStorage.getItem("token");
			const res = await fetch(`https://emotune-jik6.onrender.com/recommend/music-api?emotion=${emotion}`, {
				headers: {
					Authorization: `Bearer ${token}`
				}
			});
			const songList = await res.json();
			setSongs(songList);
		} catch (err) {
			console.error('Failed to fetch songs:', err);
		}
	};

	return (
		<div className="relative overflow-y-auto flex flex-col items-center justify-start w-full p-6">
			<div className="relative w-full max-w-4xl rounded-xl bg-white aspect-video mt-10">
				{capturedImage ? (
					<img
						src={capturedImage}
						alt="Captured"
						className="w-full h-full rounded-xl object-cover"
					/>
				) : (
					<video
						ref={videoRef}
						autoPlay
						playsInline
						onCanPlay={() => setVideoReady(true)}
						className={`w-full h-full rounded-xl ${showVideo ? 'block' : 'invisible'}`}
					/>
				)}
				<canvas ref={canvasRef} className="hidden" />
			</div>

			<div className="flex items-center justify-center bg-gray-300 px-6 py-3 rounded-full shadow-inner gap-6 mt-5">
				<button
					onClick={() => { startWebcam(); setVideo(true); }}
					className="w-10 h-10 bg-red-600 rounded-full border-4 border-white shadow"
					title="Start"
				/>

				<button
					onClick={captureImage}
					className="w-10 h-10 bg-red-500 rounded-md border-4 border-white shadow"
					title="Capture"
				/>
				<button
					onClick={() => { stopWebcam(); setVideo(false); }}
					className="w-10 h-10 bg-white rounded-full border-4 border-white shadow-inner"
					title="Stop"
				/>
			</div>

			{loading && <h6 className="text-white animate-pulse">Analyzing emotion...</h6>}

			{!loading && emotion && (
				<div className="w-full mt-4 px-4 text-center">
					<p className="text-xl font-md">
						Feels like you are <span className="font-bold">{emotion}</span>
					</p>
				</div>
			)}

			{/* Song Cards on the Right Side */}
			{emotion && songs.length > 0 && (
				<div className="fixed top-15 right-40 flex flex-col items-end gap-5 z-50">
					<AnimatePresence>
						{songs.slice(0, 5).map((song, i) => (
							<motion.div
								key={song.name + i}
								initial={{ y: 100, opacity: 0 }}   
								animate={{ y: 0, opacity: 1 }}    
								exit={{ y: 100, opacity: 0 }}
								transition={{
									delay: i * 0.1,
									type: 'spring',
									stiffness: 100,
									damping: 15,                    
								}}
								className="w-[400px]"
							>
								<SongCard 
									song={song} 
									onAddToPlaylist={openAddToPlaylistModal}
									emotion={emotion}
								/>
							</motion.div>
						))}
					</AnimatePresence>
				</div>
			)}

			{/* Playlist Modal */}
			<PlaylistModal
				open={modalOpen}
				onClose={() => setModalOpen(false)}
				song={currentSong}
				userId={userId}
			/>
		</div>
	);
};

export default WebcamCapture;