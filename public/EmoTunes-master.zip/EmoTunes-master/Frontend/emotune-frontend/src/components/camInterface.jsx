import React from 'react'
import WebcamCapture from '../components/webCamCapture';

const CamInterface = () => {
  return (
    //parent div
    <div className='flex w-[450px] h-[400px] rounded-lg mt-2 ml-12'>
        <div className='items-center justify-center flex flex-col w-full h-full'>
            <WebcamCapture/>
        </div>
    </div>
  )
}

export default CamInterface
