import React from 'react';
import ForegroundButton from './ForegroundButton';

const Foreground = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center space-y-4">
      <h1 className="text-6xl font-bold text-black">EmoTune</h1>
      <p className="text-xl text-black">Your Mood. Your Music.</p>
      <ForegroundButton />
    </div>
  );
};

export default Foreground;