import React, {useEffect} from "react";
import { motion, useMotionValue, useSpring, useTransform} from "framer-motion";
import Sun from "../assets/Sun.svg";

const AnimatedSunPointer = ({targetId}) => {
    const mouseX = useMotionValue(0);
    const mouseY = useMotionValue(0);

    const springX = useSpring(mouseX, {stiffness: 100, damping: 20})
    const springY = useSpring(mouseY, {stiffness: 100, damping: 20})
    
    useEffect(() => {
        const target = document.getElementById(targetId);
        if (!targetId) return;

        const rect = target.getBoundingClientRect();
        const centerX = rect.width / 2 - 150;
        const centerY = rect.height / 2 - 120;
        mouseX.set(centerX);
        mouseY.set(centerY);

        const handleMouseMove = (e) => {
            const rect = target.getBoundingClientRect();
            if (
                e.clientX >= rect.left &&
                e.clientX <= rect.right &&
                e.clientY >= rect.top &&
                e.clientY <= rect.bottom
            ) {
                mouseX.set(e.clientX - rect.left - 150);
                mouseY.set(e.clientY - rect.top - 120);
            } else {
                mouseX.set(centerX);
                mouseY.set(centerY);
            };
        }
            
        window.addEventListener("mousemove", handleMouseMove);
        return () => window.removeEventListener("mousemove", handleMouseMove);
    }, [mouseX, mouseY, targetId]);

    return (
        <motion.div
            style={{position: "absolute", 
                top: 0, 
                left: 0, 
                x: springX, 
                y: springY, 
                width: "311px", 
                height: "243px", 
                pointerEvents: "none"}}
        >
            <img src={Sun} alt="sun" style={{width: "80%", height: "80%"}}></img>
        </motion.div>
    )

}

export default AnimatedSunPointer;
