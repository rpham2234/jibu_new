import React from "react";

const SigninFormFields = ({ formData, onChange }) => (
    <>
      <div>
        <label className="text-lg font-medium">Email</label>
        <input
          type="email"
          name="email"
          placeholder="you@example.com"
          value={formData.email}
          onChange={onChange}
          className="border-b w-full outline-none py-2"
        />
      </div>
      <div>
        <label className="text-lg font-medium">Password</label>
        <input
          type="password"
          name="password"
          placeholder="************"
          value={formData.password}
          onChange={onChange}
          className="border-b w-full outline-none py-2"
        />
      </div>
    </>
  );
  
  export default SigninFormFields;
  