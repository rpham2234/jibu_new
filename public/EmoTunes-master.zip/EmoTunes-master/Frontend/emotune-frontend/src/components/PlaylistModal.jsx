import React, { useState, useEffect } from 'react';

const PlaylistModal = ({ open, onClose, song, userId }) => {
  const [playlists, setPlaylists] = useState([]);
  const [playlistName, setPlaylistName] = useState('');
  const [selectedPlaylist, setSelectedPlaylist] = useState(null);
  const [loading, setLoading] = useState(false);
  const token = localStorage.getItem('token');

  // Fetch user's playlists
  useEffect(() => {
    if (open && userId) {
      console.log('Fetching playlists for userId:', userId);
      fetch(`https://emotune-jik6.onrender.com/api/playlists/user/${userId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      })
        .then(async res => {
          if (!res.ok) throw new Error(await res.text());
          return res.json();
        })
        .then(data => {
          console.log('Fetched playlists:', data);
          setPlaylists(data);
        })
        .catch(err => {
          setPlaylists([]);
          console.error('Failed to fetch playlists:', err);
        });
    }
  }, [open, userId, token]);

  // Create playlist and add song
  const handleCreate = async () => {
    if (!playlistName.trim()) {
      alert('Please enter a playlist name');
      return;
    }
    
    setLoading(true);
    
    try {
      console.log('Creating playlist with song:', song);
      const songIdentifier = song?.name || song?.id || song?.songId || 'Unknown Song';
      
      const response = await fetch('https://emotune-jik6.onrender.com/api/playlists/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: playlistName,
          userId: parseInt(userId),
          songIds: [songIdentifier]
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText);
      }

      const result = await response.json();
      console.log('Playlist created successfully:', result);
      
      setPlaylistName('');
      alert('Playlist created successfully!');
      onClose();
      
    } catch (err) {
      console.error('Failed to create playlist:', err);
      alert('Failed to create playlist: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Add song to an existing playlist
  const handleAdd = async () => {
    if (!selectedPlaylist) {
      alert('Please select a playlist');
      return;
    }
    
    setLoading(true);
    
    try {
      console.log('Adding song to playlist:', selectedPlaylist, song);
      const songIdentifier = song?.name || song?.id || song?.songId || 'Unknown Song';
      
      const response = await fetch(`https://emotune-jik6.onrender.com/api/playlists/${selectedPlaylist}/add-song`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(songIdentifier),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText);
      }

      const result = await response.json();
      console.log('Song added successfully:', result);
      
      alert('Song added to playlist successfully!');
      onClose();
      
    } catch (err) {
      console.error('Failed to add song:', err);
      alert('Failed to add song: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-96 relative">
        <button 
          className="absolute top-2 right-4 text-xl hover:text-red-500" 
          onClick={onClose}
          disabled={loading}
        >
          ✕
        </button>
        
        <h3 className="text-xl mb-4 text-black">Add to Playlist</h3>
        
        {song && (
          <div className="mb-4 p-2 bg-gray-100 rounded text-black text-sm">
            <strong>Song:</strong> {song.name || song.id || song.songId || 'Unknown Song'}
            {song.artist && <><br/><strong>Artist:</strong> {song.artist}</>}
          </div>
        )}
        
        <div className="mb-4">
          <input
            value={playlistName}
            onChange={e => setPlaylistName(e.target.value)}
            placeholder="New playlist name"
            className="border p-2 w-full text-black"
            disabled={loading}
          />
          <button
            className="mt-2 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
            onClick={handleCreate}
            disabled={loading || !playlistName.trim()}
          >
            {loading ? 'Creating...' : 'Create & Add'}
          </button>
        </div>
        
        <div className="mt-4">
          <div className="mb-2 font-bold text-black">Or add to existing:</div>
          {playlists.length === 0 ? (
            <p className="text-gray-500 text-sm">No existing playlists found.</p>
          ) : (
            <>
              {playlists.map(pl => (
                <div key={pl.id} className="flex items-center mb-2">
                  <input
                    type="radio"
                    id={`playlist-${pl.id}`}
                    checked={selectedPlaylist === pl.id}
                    onChange={() => setSelectedPlaylist(pl.id)}
                    disabled={loading}
                  />
                  <label htmlFor={`playlist-${pl.id}`} className="ml-2 text-black cursor-pointer">
                    {pl.name} ({pl.songIds?.length || 0} songs)
                  </label>
                </div>
              ))}
              <button
                className="mt-2 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
                onClick={handleAdd}
                disabled={loading || !selectedPlaylist}
              >
                {loading ? 'Adding...' : 'Add to Selected Playlist'}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PlaylistModal;
