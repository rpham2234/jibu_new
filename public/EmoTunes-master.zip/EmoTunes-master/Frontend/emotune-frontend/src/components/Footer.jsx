import React from 'react'
const Footer = () => {
  return (
    <footer className="mt-16 px-6 py-10 bg-gray-100 text-black text-sm">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Contact */}
        <div>
          <h3 className="text-lg font-semibold mb-2">Contact</h3>
          <p>Email: <a href="mailto:contact@emotune.app" className="underline hover:text-blue-500">contact@emotune.app</a></p>
        </div>

        {/* GitHub */}
        <div>
          <h3 className="text-lg font-semibold mb-2">GitHub</h3>
          <a
            href="https://github.com/yashpokharna2555/EmoTunes.git"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-blue-500"
          >
            github.com/yashpokharna2555/EmoTunes
          </a>
        </div>

        {/* Credits */}
        <div>
          <h3 className="text-lg font-semibold mb-2">Credits</h3>
          <ul className="list-disc list-inside space-y-1">
            <li>Emotion Detection powered by <a href="https://deepmind.google/technologies/gemini/" target="_blank" className="underline hover:text-blue-500">Google Gemini API</a></li>
            <li>Music Recommendations via <a href="https://developer.spotify.com/documentation/web-api/" target="_blank" className="underline hover:text-green-600">Spotify API</a></li>
            <li>Visuals & Illustrations from <a href="https://www.unsplash.com/" target="_blank" className="underline hover:text-purple-500">Unsplash</a> and original SVGs</li>
          </ul>
        </div>

        <div className="pt-6 border-t text-xs text-gray-500">
          © {new Date().getFullYear()} EmoTune. All rights reserved.
        </div>
      </div>
    </footer>
  )
}

export default Footer
