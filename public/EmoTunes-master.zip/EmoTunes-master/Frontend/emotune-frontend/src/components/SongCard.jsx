import React, { useState } from "react";

const SongCard = ({ song, onAddToPlaylist, emotion }) => {
    const [liked, setLiked] = useState(false);
    const [disliked, setDisliked] = useState(false);
    const [loading, setLoading] = useState(false);

    const handleFeedback = async (feedbackType) => {
        setLoading(true);
        try {
            const token = localStorage.getItem("token");
            const songIdentifier = song?.name || song?.id || song?.songId || 'Unknown Song';
            
            const response = await fetch("https://emotune-jik6.onrender.com/recommend/music/feedback", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    songId: songIdentifier,
                    emotion: emotion,
                    feedback: feedbackType
                })
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText);
            }

            // Update UI state based on feedback
            if (feedbackType === 'like') {
                setLiked(true);
                setDisliked(false);
                // Success alert for like
                alert(`❤️ Liked "${song.name}" by ${song.artist}!\nIt will appear in your liked songs on the History page.`);
            } else if (feedbackType === 'dislike') {
                setDisliked(true);
                setLiked(false);
                // Success alert for dislike
                alert(`👎 Disliked "${song.name}" by ${song.artist}.\nWe'll avoid recommending similar songs.`);
            }

            console.log(`${feedbackType} feedback saved for song: ${songIdentifier}`);
            
        } catch (error) {
            console.error(`Failed to save ${feedbackType}:`, error);
            alert(`❌ Failed to save ${feedbackType}. Please try again.`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-white rounded-2xl shadow-xl/30 p-4 flex items-center gap-4 w-full group hover:shadow-2xl transition-all duration-300">
            {song.url && (
                <a
                    href={song.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block w-6 h-6 hover:scale-110 transition-transform"
                >
                    {/* Spotify SVG logo */}
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 168 168"
                        fill="currentColor"
                        className="w-full h-full text-green-500"
                    >
                        <path d="M84,0C37.6,0,0,37.6,0,84s37.6,84,84,84s84-37.6,84-84S130.4,0,84,0z M121.3,121.1c-1.5,2.4-4.6,3.1-7,1.6  c-19.2-11.8-43.3-14.4-71.7-7.7c-2.7,0.6-5.4-1.1-6-3.8c-0.6-2.7,1.1-5.4,3.8-6c31.9-7.4,59.2-4.4,81.3,8.8  C122.1,116.1,122.8,118.8,121.3,121.1z M132.2,101.1c-1.9,3-5.8,3.9-8.8,2c-22-13.5-55.6-17.4-81.5-9.3c-3.4,1-6.9-0.9-7.8-4.2  c-1-3.4,0.9-6.9,4.2-7.8c30.1-9.2,68.6-5.1,94.1,11C133.3,93.7,134.1,98.1,132.2,101.1z M133.3,80.4c-26.2-15.6-69.5-17-94.2-9.1  c-4,1.3-8.3-0.9-9.6-4.9c-1.3-4,0.9-8.3,4.9-9.6c29.6-9.2,78.6-7.5,109.7,10.5c3.6,2.1,4.7,6.7,2.6,10.3  C144.6,81.2,139.1,83.9,133.3,80.4z" />
                    </svg>
                </a>
            )}
            
            <div className="flex flex-col flex-1">
                <h6 className="font-semibold text-sm text-gray-800">{song.name}</h6>
                <h6 className="text-xs text-gray-500">{song.artist}</h6>
                {song.album && (
                    <h6 className="text-xs text-gray-400">{song.album}</h6>
                )}
            </div>
            
            {/* Action Buttons Container */}
            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all duration-200">
                {/* Like Button */}
                <button
                    onClick={() => handleFeedback('like')}
                    disabled={loading}
                    className={`p-2 rounded-full transition-all duration-200 transform hover:scale-110 ${
                        liked 
                            ? 'bg-red-500 text-white shadow-lg' 
                            : 'bg-gray-100 hover:bg-red-100 text-gray-600 hover:text-red-500'
                    } disabled:opacity-50`}
                    title="Like this song"
                >
                    <svg 
                        className="w-4 h-4" 
                        fill={liked ? "currentColor" : "none"}
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                    >
                        <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={2} 
                            d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" 
                        />
                    </svg>
                </button>

                {/* Dislike Button */}
                <button
                    onClick={() => handleFeedback('dislike')}
                    disabled={loading}
                    className={`p-2 rounded-full transition-all duration-200 transform hover:scale-110 ${
                        disliked 
                            ? 'bg-gray-700 text-white shadow-lg' 
                            : 'bg-gray-100 hover:bg-gray-200 text-gray-600 hover:text-gray-700'
                    } disabled:opacity-50`}
                    title="Dislike this song"
                >
                    <svg 
                        className="w-4 h-4" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                    >
                        <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={2} 
                            d="M7 13l3 3 7-7" 
                            transform="rotate(180 12 12)"
                        />
                        <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={2} 
                            d="M6 18L18 6M6 6l12 12" 
                        />
                    </svg>
                </button>

                {/* Add to Playlist Button */}
                <button
                    onClick={() => onAddToPlaylist(song)}
                    disabled={loading}
                    className="bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 
                               text-white px-3 py-2 rounded-lg text-xs font-medium 
                               transform hover:scale-105 transition-all duration-200 
                               shadow-md hover:shadow-lg flex items-center gap-1 disabled:opacity-50"
                    title="Add to Playlist"
                >
                    <svg 
                        className="w-3 h-3" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                    >
                        <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={2} 
                            d="M12 4v16m8-8H4" 
                        />
                    </svg>
                    Add
                </button>
            </div>
        </div>
    );
};

export default SongCard;