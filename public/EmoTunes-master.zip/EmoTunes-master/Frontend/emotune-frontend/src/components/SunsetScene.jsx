import React from 'react'
import Clouds from './Clouds';
import Sun from './Sun'
import Fly from './Birds';

const SunsetScene = () => {
  return (
    <div className="relative w-full h-screen bg-gradient-to-b from-purple-900 to-orange-300 overflow-hidden">
        <Sun />
        <Clouds />
        <Fly/> 
    </div>
  )
}

export default SunsetScene
