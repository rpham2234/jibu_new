import React from 'react'
import { useState } from 'react';
import { motion } from 'framer-motion';
import Yash from "../assets/avatars/yashAvatar.png"
import Chandan from "../assets/avatars/chandan.png"
import Gpt from "../assets/avatars/gptLogo.jpg"
import Gemini from "../assets/avatars/geminiAvatar.png"
import Gaurav from "../assets/avatars/gauravAvatar.png"


const teamMembers = [
  {
    name: 'Gaurav Hungund',
    role: 'Full Stack Developer',
    description: 'Writes code, breaks code, then fixes it heroically just before deadlines.',
    image: Gaurav,
    ai: false
  },
  {
    name: 'Chandan Dhamandle',
    role: 'UI/UX Designer',
    description: 'Designs with precision and passion. Figma is basically his second language.',
    image: Chandan,
    ai: false
  },
  {
    name: 'Yash Pokharna',
    role: 'Backend Engineer / Design Pattern Architect',
    description: 'Breathes Spring Boot. Dreams in UML diagrams. Optimizes like a monk.',
    image: Yash,
    ai: false
  },
  {
    name: 'Gemini API',
    role: 'Emotion Whisperer',
    description: 'Reads your face like an open book. Might secretly write poetry. Powered by quantum vibes.',
    image: Gemini,
    ai: true
  },
  {
    name: 'ChatGPT',
    role: 'Verbose Overthinker',
    description: 'Talks too much. Knows too much. Will explain recursion with a recursive poem if you ask.',
    image: Gpt,
    ai: true
  }
];

const TeamSection = () => {
  const [showAI, setShowAI] = useState(false);

  return (
    <section className="py-16 space-y-12">
      <h2 className="text-3xl font-semibold text-center mb-4">Meet the Team</h2>

      <div className="text-center">
        <button
          onClick={() => setShowAI(!showAI)}
          className="px-5 py-2 text-sm bg-black text-white rounded-full hover:bg-gray-800 transition"
        >
          {showAI ? 'Hide AI Members' : 'Reveal All Team Members'}
        </button>
      </div>

      <div className="space-y-14">
        {teamMembers
          .filter(member => showAI || !member.ai)
          .map((member, index) => (
            <motion.div
              key={index}
              className={`flex flex-col md:flex-row ${
                index % 2 === 1 ? 'md:flex-row-reverse' : ''
              } items-center gap-6 px-4`}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              viewport={{ once: true }}
            >
              {/* Avatar */}
              <div
                className={`w-32 h-32 rounded-full overflow-hidden border-4 border-black shadow-md ${
                  member.ai ? 'animate-spin-slow' : ''
                }`}
              >
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Info Card */}
              <div className="max-w-xl bg-white/70 p-4 rounded-lg shadow-md text-center md:text-left">
                <h3 className="text-xl font-bold">{member.name}</h3>
                <p className="text-sm font-semibold text-black">{member.role}</p>

                <p className="mt-2 text-base text-gray-800 italic relative pl-6 before:content-['“'] before:text-4xl before:absolute before:left-0 before:top-[-4px]">
                  {member.description}
                </p>

                {member.ai && (
                  <div className="mt-3 space-y-1">
                    <button
                      onClick={() =>
                        alert(
                          `${member.name} attempted to take over EmoTune.\n\n🚫 Access Denied: Humans still run the show.`
                        )
                      }
                      className="px-3 py-1 text-sm bg-purple-100 hover:bg-purple-200 rounded-full font-medium transition"
                    >
                      Promote to CEO 👑
                    </button>
                    <p className="text-xs text-purple-500">
                      ⚠️ This team member may hallucinate reality. Proceed with curiosity.
                    </p>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
      </div>
    </section>
  );
};

export default TeamSection;
