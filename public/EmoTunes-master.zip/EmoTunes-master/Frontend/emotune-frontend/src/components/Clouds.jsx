import React from "react";
import { motion } from "framer-motion";
import Cloud1  from "../assets/Cloud1.svg";
import Cloud2  from "../assets/Cloud2.svg";
import Cloud3  from "../assets/Cloud3.svg";
import Cloud4  from "../assets/Cloud4.svg";
import Cloud5  from "../assets/Cloud5.svg";

const Clouds = () => {
    return (
        <div className="absolute inset-0 pointer-events-none z-50">
            {/* left side clouds */}
            <motion.img 
            src={Cloud1} className="absolute bottom-[-20px] left-[-30px] w-[500px] z-15"
            initial={{ opacity: 0, x: -320 }}
            animate={{ opacity: 1, x: 150 }}
            transition={{ duration: 1.6 }}
            />

            <motion.img 
            src={Cloud2} className="absolute bottom-[50px] left-[90px] w-[750px] h-[250px] z-5"
            initial={{ opacity: 0, x: -300 }}
            animate={{ opacity: 1, x: -270 }}
            transition={{ duration: 1.6 }}
            />

            <motion.img src={Cloud3} className="absolute bottom-[-20px] left-[-10px] w-[400px] z-10"
            initial={{opacity: 0, x: -100}}
            animate={{opacity: 1, x: 10}}
            transition={{duration: 1.6}}
            />

            {/* <motion.img src={Cloud4} className="absolute h-[350px] bottom-[-120px] left-[240px] w-[400px] z-50 "
            initial={{opacity: 0, x: -320}}
            animate={{opacity: 1, x: 10}}
            transition={{duration: 1.5}}
            />  

            <motion.img src={Cloud5} className="absolute bottom-[-40px] left-[-40px] w-[300px] h-[200px] z-50"
            initial={{opacity: 0, x: -330}}
            animate={{opacity: 1, x: -20}}
            transition={{duration: 1.5}}
            /> */}


            {/* {right side clouds} */}

            <motion.img 
            src={Cloud1} className="absolute bottom-[-20px] right-[0px] w-[400px] z-10"
            initial={{ opacity: 0, x: 350 }}
            animate={{ opacity: 1, x: -250 }}
            transition={{ duration: 1.6 }}
            />

            {/* <motion.img 
            src={Cloud2} className="absolute bottom-[80px] right-[-10px] w-[350px] z-50"
            initial={{ opacity: 0, x: 320 }}
            animate={{ opacity: 1, x: 30 }}
            transition={{ duration: 1.6 }}
            /> */}

            <motion.img src={Cloud3} className="absolute bottom-[40px] right-50 w-[450px] z-0"
            initial={{opacity: 0, x: 330}}
            animate={{opacity: 1, x: 300}}
            transition={{duration: 1.6}}
            />

            <motion.img src={Cloud4} className="absolute bottom-[-150px] right-[-20px] w-[450px] h-[450px] z-5 "
            initial={{opacity: 0, x: 400}}
            animate={{opacity: 1, x: 0}}
            transition={{duration: 1.6}}
            />

            <motion.img src={Cloud5} className="absolute bottom-[50px] right-70 w-[250px] z-1"
            initial={{opacity: 0, x: 300}}
            animate={{opacity: 1, x: 50}}
            transition={{duration: 1.5}}
            />
    </div>
    )
    
}

export default Clouds;
