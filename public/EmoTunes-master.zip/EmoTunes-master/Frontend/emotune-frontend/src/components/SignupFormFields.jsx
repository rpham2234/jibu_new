import React from "react";

const SignupFormFields = ({ formData, onChange, isVerifying }) => (
    <>
      {!isVerifying && (
        <>
          <div>
            <label className="text-lg font-medium">Username</label>
            <input
              type="text"
              name="username"
              placeholder="Choose a username"
              value={formData.username}
              onChange={onChange}
              className="border-b w-full outline-none py-2"
            />
          </div>
          <div>
            <label className="text-lg font-medium">Email</label>
            <input
              type="email"
              name="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={onChange}
              className="border-b w-full outline-none py-2"
            />
          </div>
          <div>
            <label className="text-lg font-medium">Password</label>
            <input
              type="password"
              name="password"
              placeholder="************"
              value={formData.password}
              onChange={onChange}
              className="border-b w-full outline-none py-2"
            />
          </div>
        </>
      )}
  
      {isVerifying && (
        <div>
          <label className="text-lg font-medium">Verification Code</label>
          <input
            type="text"
            name="verificationCode"
            placeholder="Enter code sent to email"
            value={formData.verificationCode}
            onChange={onChange}
            className="border-b w-full outline-none py-2"
          />
        </div>
      )}
    </>
  );
  
  export default SignupFormFields;
  