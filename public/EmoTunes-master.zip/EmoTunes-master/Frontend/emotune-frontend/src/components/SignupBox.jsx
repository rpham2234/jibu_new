import React, { useState } from "react";
import { motion, AnimatePresence, easeIn } from "framer-motion";
import AnimatedTunes from "./AnimatedTunes";
import SigninFormFields from "./SigninFormFields";
import SignupFormFields from "./SignupFormFields";
import axios from "../axiosConfig"; // instead of 'axios'
import { useNavigate } from "react-router-dom";

const SignupBox = () => {
    const [activeTab, setActiveTab] = useState("signup");
    const [isVerifying, setIsVerifying] = useState(false);
    const [agree, setAgree] = useState(false);
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        username: "",
        email: "",
        password: "",
        verificationCode: "",
    });

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const resetState = () => {
        setFormData({
        username: "",
        email: "",
        password: "",
        verificationCode: "",
        });
        setIsVerifying(false);
    };

const handleSubmit = async (e) => {
  e.preventDefault();

  try {
    if (activeTab === "signin") {
      console.log("📤 Sending login request:", {
        email: formData.email,
        password: formData.password,
      });

      const response = await axios.post("/auth/login", {
        email: formData.email,
        password: formData.password,
      });

      console.log("✅ Login success:", response.data);
      localStorage.setItem("token", response.data.token);
      localStorage.setItem("username", formData.email.split("@")[0]); // or actual username
      localStorage.setItem("user_id", response.data.userId.toString());
      navigate("/")

    } else if (!isVerifying) {
      const signupPayload = {
        username: formData.username,
        email: formData.email,
        password: formData.password,
      };

      console.log("📤 Sending signup request:", signupPayload);

      const response = await axios.post("/auth/signup", signupPayload);

      console.log("✅ Signup success:", response.data);
      setIsVerifying(true);

    } else {
      const verifyPayload = {
        email: formData.email,
        verificationCode: formData.verificationCode,
      };

      console.log("📤 Sending verification request:", verifyPayload);

      const response = await axios.post("/auth/verify", verifyPayload);

      console.log("✅ Verification success:", response.data);
      resetState();
      setActiveTab("signin");
    }
  } catch (err) {
    console.error("❌ Auth error:", err.response?.data || err.message);
  }
};

    return (
        <div className="bg-white w-[650px] rounded-[30px] shadow-[10px_10px_20px_rgba(0,0,0,0.2)] p-10 flex gap-6">
        {/* Tunes Icon */}
        <div className="flex items-center justify-center">
            <AnimatedTunes />
        </div>

        <div className="flex flex-col justify-center w-full">
            {/* Toggle */}
            <div className="relative bg-gray-100 p-1 rounded-full w-fit mx-auto mb-6 flex items-center">
            <motion.div
                layout
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className={`absolute top-0 left-0 w-1/2 h-full bg-black rounded-full ${
                activeTab === "signup" ? "translate-x-full" : "translate-x-0"
                }`}
            />
            <button
                onClick={() => {
                setActiveTab("signin");
                resetState();
                }}
                className={`relative z-10 px-6 py-2 rounded-full transition-colors duration-200 ${
                activeTab === "signin" ? "text-white" : "text-black"
                }`}
            >
                Sign In
            </button>
            <button
                onClick={() => {
                setActiveTab("signup");
                resetState();
                }}
                className={`relative z-10 px-6 py-2 rounded-full transition-colors duration-200 ${
                activeTab === "signup" ? "text-white" : "text-black"
                }`}
            >
                Sign Up
            </button>
            </div>

            {/* Form */}
            <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
                <AnimatePresence mode="wait">
                    {activeTab === "signin" ? (
                    <SigninFormFields
                        key="signin"
                        formData={formData}
                        onChange={handleInputChange}
                    />
                    ) : (
                    <SignupFormFields
                        key="signup"
                        formData={formData}
                        onChange={handleInputChange}
                        isVerifying={isVerifying}
                    />
                    )}
                </AnimatePresence>

            <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-full w-fit self-end mt-2"
            >
                {activeTab === "signin"
                ? "Sign In"
                : isVerifying
                ? "Verify Code"
                : "Submit"}
            </button>

            <div
                className="flex items-center gap-2 text-sm text-gray-500 mt-2 cursor-pointer select-none"
                onClick={() => setAgree(!agree)}
                >
                <div
                    className={`w-3 h-3 rounded-full border ${
                    agree ? "bg-green-500 border-green-500" : "bg-red-600 border-red-600"
                    } transition-all duration-200`}
                />
                <span>
                    I agree to all the statements in{" "}
                    <a href="#" className="underline">
                    terms and conditions of service
                    </a>
                </span>
            </div>

        </form>
        </div>
        </div>
    );
};

export default SignupBox;
