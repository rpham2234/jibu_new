import React from "react";
import { motion } from "framer-motion";

const Sun = () => {
    return (
        <>
            <motion.div
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-orange-500 rounded-t-full z-40 flex items-center justify-center"
                initial={{ y: "100%"}}
                animate={{y: 0}}
                transition={{type: "tween", ease: "easeOut", duration: 2}}
            >
                <svg width="200" height="200" viewBox="0 0 100 100" fill="none">
                <path d="M30 45 Q35 40 40 45" stroke="black" strokeWidth="5" strokeLinecap="round" />
                <path d="M60 45 Q65 40 70 45" stroke="black" strokeWidth="5" strokeLinecap="round" />
                <path d="M35 65 Q50 80 65 65" stroke="black" strokeWidth="5" strokeLinecap="round" />
                </svg>
            </motion.div>
        </>
    )
}

export default Sun;
