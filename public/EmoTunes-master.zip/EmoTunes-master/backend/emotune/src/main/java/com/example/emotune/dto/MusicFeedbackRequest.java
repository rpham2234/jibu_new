package com.example.emotune.dto;

import lombok.Data;

@Data
public class MusicFeedbackRequest {
    private String songId;
    private String emotion;
    private String feedback;
}
