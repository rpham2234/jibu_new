// state/RecommendationState.java
package com.example.emotune.state;

import java.util.List;

public interface RecommendationState {
    List<String> recommend(Long userId, String emotion);
    String getStateName();
}
