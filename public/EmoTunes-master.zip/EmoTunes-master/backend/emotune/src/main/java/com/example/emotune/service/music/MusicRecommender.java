package com.example.emotune.service.music;

import java.util.List;
import java.util.Map;
public interface MusicRecommender {
    List<Map<String, String>> recommendMusic(String emotion);
}
