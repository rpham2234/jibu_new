package com.example.emotune.activity;

import java.util.List;

public interface ActivityRecommender {
    List<String> recommendActivity();
}
