package com.example.emotune.state;

import com.example.emotune.model.MusicFeedback;
import com.example.emotune.repository.MusicFeedbackRepository;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

@Component
public class PersonalizedState implements RecommendationState {
    private final MusicFeedbackRepository feedbackRepo;

    public PersonalizedState(MusicFeedbackRepository feedbackRepo) {
        this.feedbackRepo = feedbackRepo;
    }

    @Override
    public List<String> recommend(Long userId, String emotion) {
        List<MusicFeedback> likedFeedbacks = feedbackRepo.findByUserIdAndEmotionAndFeedback(userId, emotion, "like");
        List<String> liked = likedFeedbacks.stream()
                .map(MusicFeedback::getSongId)
                .collect(Collectors.toList());
        System.out.println("[DEBUG] Liked songs for user=" + userId + ", emotion=" + emotion + " : " + liked);
        if (!liked.isEmpty()) return liked;

        List<String> allForEmotion = feedbackRepo.findMostLikedSongIdsByEmotion(emotion);
        List<MusicFeedback> dislikedFeedbacks = feedbackRepo.findByUserIdAndEmotionAndFeedback(userId, emotion, "dislike");
        List<String> disliked = dislikedFeedbacks.stream()
                .map(MusicFeedback::getSongId)
                .collect(Collectors.toList());
        System.out.println("[DEBUG] Fallback pool for emotion=" + emotion + " before removing dislikes: " + allForEmotion);
        System.out.println("[DEBUG] Disliked by user: " + disliked);
        allForEmotion.removeAll(disliked);
        System.out.println("[DEBUG] Final recommended after removing dislikes: " + allForEmotion);
        return allForEmotion;
    }


    @Override
    public String getStateName() {
        return "Personalized";
    }
}
