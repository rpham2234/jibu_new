package com.example.emotune.controller;

import com.example.emotune.responses.EmotionResponse;
import com.example.emotune.service.EmotionDetectionService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/emotion")
public class EmotionController {

    private final EmotionDetectionService emotionDetectionService;

    public EmotionController(EmotionDetectionService emotionDetectionService) {
        this.emotionDetectionService = emotionDetectionService;
    }

    // This endpoint is authenticated via JWT (see SecurityConfig, you already did)
    @PostMapping(value = "/detect", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<EmotionResponse> detectEmotion(@RequestParam("image") MultipartFile image) {
        System.out.println("Inside detectEmotion route");
        String emotion = emotionDetectionService.detectEmotion(image);
        return ResponseEntity.ok(new EmotionResponse(emotion));
    }

    @GetMapping("/test")
    public String test() {
        return "ok";
    }
}
