package com.example.emotune.factory;

import com.example.emotune.service.music.MusicRecommender;
import com.example.emotune.service.music.SpotifyMusicAdapter;
import com.example.emotune.activity.ActivityRecommender;
import com.example.emotune.activity.SurprisedActivityRecommender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("surprisedRecommendationFactory")
public class SurprisedRecommendationFactory implements EmotionRecommendationFactory {

    private final SpotifyMusicAdapter spotifyMusicAdapter;
    private final SurprisedActivityRecommender surprisedActivityRecommender;

    @Autowired
    public SurprisedRecommendationFactory(SpotifyMusicAdapter spotifyMusicAdapter,
                                          SurprisedActivityRecommender surprisedActivityRecommender) {
        this.spotifyMusicAdapter = spotifyMusicAdapter;
        this.surprisedActivityRecommender = surprisedActivityRecommender;
    }

    @Override
    public MusicRecommender createMusicRecommender() {
        return spotifyMusicAdapter;
    }

    @Override
    public ActivityRecommender createActivityRecommender() {
        return surprisedActivityRecommender;
    }
}
