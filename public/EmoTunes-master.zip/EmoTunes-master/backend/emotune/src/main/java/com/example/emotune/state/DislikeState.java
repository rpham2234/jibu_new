package com.example.emotune.state;

public class DislikeState implements FeedbackState {
    @Override
    public String handle(String feedback) {
        return "dislike".equalsIgnoreCase(feedback) ? "Negative" : "Neutral";
    }
}
