package com.example.emotune.chain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RecommendationChainBuilder {

    private final FeedbackFilterHandler feedbackFilterHandler;
    private final DuplicateFilterHandler duplicateFilterHandler;

    @Autowired
    public RecommendationChainBuilder(FeedbackFilterHandler feedbackFilterHandler,
                                      DuplicateFilterHandler duplicateFilterHandler) {
        this.feedbackFilterHandler = feedbackFilterHandler;
        this.duplicateFilterHandler = duplicateFilterHandler;
    }

    public RecommendationHandler buildChain() {
        feedbackFilterHandler.setNext(duplicateFilterHandler);
        return feedbackFilterHandler;
    }
}
