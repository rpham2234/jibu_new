package com.example.emotune.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "music_feedback")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MusicFeedback {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "song_id")
    private String songId;

    @Column(name = "emotion")
    private String emotion;

    @Column(name = "feedback")
    private String feedback; // "like" or "dislike"

    @Column(name = "timestamp")
    private LocalDateTime timestamp;
}
