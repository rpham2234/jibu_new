// src/main/java/com/example/emotune/command/SaveFeedbackCommand.java
package com.example.emotune.command;

import com.example.emotune.model.MusicFeedback;
import com.example.emotune.repository.MusicFeedbackRepository;

public class SaveFeedbackCommand implements FeedbackCommand {
    private final MusicFeedbackRepository repository;
    private final MusicFeedback feedback;

    public SaveFeedbackCommand(MusicFeedbackRepository repository, MusicFeedback feedback) {
        this.repository = repository;
        this.feedback = feedback;
    }

    @Override
    public void execute() {
        System.out.println("Saving Feedback...");
        repository.save(feedback);
    }
}
