package com.example.emotune.factory;

import com.example.emotune.service.music.MusicRecommender;
import com.example.emotune.service.music.SpotifyMusicAdapter;
import com.example.emotune.activity.ActivityRecommender;
import com.example.emotune.activity.AngryActivityRecommender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("angryRecommendationFactory")
public class AngryRecommendationFactory implements EmotionRecommendationFactory {

    private final SpotifyMusicAdapter spotifyMusicAdapter;
    private final AngryActivityRecommender angryActivityRecommender;

    @Autowired
    public AngryRecommendationFactory(SpotifyMusicAdapter spotifyMusicAdapter,
                                      AngryActivityRecommender angryActivityRecommender) {
        this.spotifyMusicAdapter = spotifyMusicAdapter;
        this.angryActivityRecommender = angryActivityRecommender;
    }

    @Override
    public MusicRecommender createMusicRecommender() {
        return spotifyMusicAdapter;
    }

    @Override
    public ActivityRecommender createActivityRecommender() {
        return angryActivityRecommender;
    }
}
