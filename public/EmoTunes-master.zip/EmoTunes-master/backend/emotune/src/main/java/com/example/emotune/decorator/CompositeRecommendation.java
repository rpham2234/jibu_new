// src/main/java/com/example/emotune/decorator/CompositeRecommendation.java
package com.example.emotune.decorator;

import java.util.ArrayList;
import java.util.List;

public class CompositeRecommendation implements Recommendation {
    private final List<Recommendation> children = new ArrayList<>();

    public void add(Recommendation recommendation) {
        children.add(recommendation);
    }

    @Override
    public List<String> getSongs() {
        List<String> result = new ArrayList<>();
        for (Recommendation child : children) {
            result.addAll(child.getSongs());
        }
        return result;
    }

    @Override
    public String getDescription() {
        StringBuilder sb = new StringBuilder();
        for (Recommendation child : children) {
            sb.append(child.getDescription()).append("; ");
        }
        return sb.toString().trim();
    }
}
