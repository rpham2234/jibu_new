package com.example.emotune.service;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.Base64;

@Component("llmStrategy")
public class LLMEmotionDetectionStrategy implements EmotionDetectionStrategy {

    @Value("${gemini.api.key}")
    private String apiKey;

    private final WebClient webClient = WebClient.builder()
            .baseUrl("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent")
            .build();

    @Override
    public String detectEmotion(MultipartFile image) {
        try {
            String base64Image = Base64.getEncoder().encodeToString(image.getBytes());

            String prompt = "Detect the user's emotion in one word from this image. Valid values: happy, sad, angry, excited, surprised, neutral. Respond with just the word.";

            String requestBody = "{\n" +
                    "  \"contents\": [\n" +
                    "    {\n" +
                    "      \"parts\": [\n" +
                    "        {\n" +
                    "          \"text\": \"" + prompt + "\"\n" +
                    "        },\n" +
                    "        {\n" +
                    "          \"inline_data\": {\n" +
                    "            \"mime_type\": \"" + image.getContentType() + "\",\n" +
                    "            \"data\": \"" + base64Image + "\"\n" +
                    "          }\n" +
                    "        }\n" +
                    "      ]\n" +
                    "    }\n" +
                    "  ]\n" +
                    "}";

            String response = webClient.post()
                    .uri("?key=" + apiKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            // Parse the response to extract the emotion word
            if (response != null) {
                JSONObject json = new JSONObject(response);
                String emotion = json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text");
                return emotion.trim(); // Should be one of the valid emotions
            } else {
                return "error";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }
}
