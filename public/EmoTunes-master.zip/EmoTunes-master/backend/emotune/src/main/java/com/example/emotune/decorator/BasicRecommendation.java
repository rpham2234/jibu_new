// src/main/java/com/example/emotune/decorator/BasicRecommendation.java
package com.example.emotune.decorator;

import java.util.List;

public class BasicRecommendation implements Recommendation {
    private final List<String> songs;

    public BasicRecommendation(List<String> songs) {
        this.songs = songs;
    }

    @Override
    public List<String> getSongs() {
        return songs;
    }

    @Override
    public String getDescription() {
        return "Standard Recommendation";
    }
}
