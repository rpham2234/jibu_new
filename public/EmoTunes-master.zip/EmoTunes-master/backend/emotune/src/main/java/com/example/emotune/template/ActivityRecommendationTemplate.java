package com.example.emotune.template;

import com.example.emotune.activity.ActivityRecommender;
import com.example.emotune.factory.EmotionRecommendationFactory;
import com.example.emotune.factory.EmotionRecommendationFactoryProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ActivityRecommendationTemplate extends RecommendationTemplate {

    private final EmotionRecommendationFactoryProvider factoryProvider;

    @Autowired
    public ActivityRecommendationTemplate(EmotionRecommendationFactoryProvider factoryProvider) {
        this.factoryProvider = factoryProvider;
    }

    @Override
    protected List<String> fetchRecommendations(Long userId, String emotion, String mode) {
        EmotionRecommendationFactory factory = factoryProvider.getFactory(emotion);
        ActivityRecommender recommender = factory.createActivityRecommender();
        return recommender.recommendActivity();
    }
}
