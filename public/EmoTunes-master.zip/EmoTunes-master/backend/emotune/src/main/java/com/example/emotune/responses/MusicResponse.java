package com.example.emotune.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@AllArgsConstructor
public class MusicResponse {
    private List<String> songs;
}
