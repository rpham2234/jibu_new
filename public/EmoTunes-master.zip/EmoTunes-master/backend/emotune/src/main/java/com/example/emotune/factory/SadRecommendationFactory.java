package com.example.emotune.factory;

import com.example.emotune.service.music.MusicRecommender;
import com.example.emotune.service.music.SpotifyMusicAdapter;
import com.example.emotune.activity.ActivityRecommender;
import com.example.emotune.activity.SadActivityRecommender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("sadRecommendationFactory")
public class SadRecommendationFactory implements EmotionRecommendationFactory {

    private final SpotifyMusicAdapter spotifyMusicAdapter;
    private final SadActivityRecommender sadActivityRecommender;

    @Autowired
    public SadRecommendationFactory(SpotifyMusicAdapter spotifyMusicAdapter,
                                    SadActivityRecommender sadActivityRecommender) {
        this.spotifyMusicAdapter = spotifyMusicAdapter;
        this.sadActivityRecommender = sadActivityRecommender;
    }

    @Override
    public MusicRecommender createMusicRecommender() {
        return spotifyMusicAdapter;
    }

    @Override
    public ActivityRecommender createActivityRecommender() {
        return sadActivityRecommender;
    }
}
