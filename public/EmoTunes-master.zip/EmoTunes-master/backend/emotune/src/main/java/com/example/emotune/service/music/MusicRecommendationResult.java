package com.example.emotune.service.music;

import java.util.List;

public class MusicRecommendationResult {
    private List<String> songs;

    public MusicRecommendationResult(List<String> songs) {
        this.songs = songs;
    }

    public List<String> getSongs() {
        return songs;
    }

    public void setSongs(List<String> songs) {
        this.songs = songs;
    }
}
