package com.example.emotune.responses;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginResponse {
    private String token;
    private long expiresIn;
    private Long userId;

    public LoginResponse(String token, long expiresIn, Long userId) {
        this.token = token;
        this.expiresIn = expiresIn;
        this.userId = userId;
    }
}