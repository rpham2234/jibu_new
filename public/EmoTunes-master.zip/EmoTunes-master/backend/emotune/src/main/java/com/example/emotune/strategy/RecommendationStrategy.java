package com.example.emotune.strategy;

import java.util.List;

public interface RecommendationStrategy {
    List<String> recommend(Long userId, String emotion);
}
