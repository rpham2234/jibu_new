// src/main/java/com/example/emotune/controller/PlaylistController.java
package com.example.emotune.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.emotune.model.Playlist;
import com.example.emotune.service.music.PlaylistService;

@RestController
@RequestMapping("/api/playlists")
@CrossOrigin(origins = "http://localhost:3000")
public class PlaylistController {
    private final PlaylistService playlistService;
    public PlaylistController(PlaylistService playlistService) {
        this.playlistService = playlistService;
    }

    @PostMapping("/create")
    public ResponseEntity<?> create(@RequestBody Map<String, Object> request) {
        try {
            String name = (String) request.get("name");
            Long userId = Long.valueOf(request.get("userId").toString());
            @SuppressWarnings("unchecked")
            List<String> songIds = (List<String>) request.get("songIds");
            
            Playlist playlist = playlistService.createPlaylist(name, userId, songIds);
            return ResponseEntity.ok(playlist);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error creating playlist: " + e.getMessage());
        }
    }

    @PostMapping("/{playlistId}/add-song")
    public ResponseEntity<?> addSong(@PathVariable Long playlistId, @RequestBody String songId) {
        try {
            Playlist playlist = playlistService.addSongToPlaylist(playlistId, songId);
            return ResponseEntity.ok(playlist);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error adding song to playlist: " + e.getMessage());
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Playlist>> getPlaylistsForUser(@PathVariable Long userId) {
        try {
            List<Playlist> playlists = playlistService.getPlaylistsForUser(userId);
            return ResponseEntity.ok(playlists);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{playlistId}")
    public ResponseEntity<Playlist> getPlaylist(@PathVariable Long playlistId) {
        try {
            Playlist playlist = playlistService.getPlaylist(playlistId);
            if (playlist != null) {
                return ResponseEntity.ok(playlist);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
