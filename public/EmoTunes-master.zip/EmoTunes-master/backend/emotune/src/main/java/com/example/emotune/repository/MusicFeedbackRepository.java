package com.example.emotune.repository;

import com.example.emotune.model.MusicFeedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

@Repository
public interface MusicFeedbackRepository extends JpaRepository<MusicFeedback, Long> {

    @Query("SELECT mf.songId " +
            "FROM MusicFeedback mf " +
            "WHERE mf.emotion = :emotion AND mf.feedback = 'like' " +
            "GROUP BY mf.songId " +
            "ORDER BY COUNT(mf.songId) DESC")
    List<String> findMostLikedSongIdsByEmotion(@Param("emotion") String emotion);

    @Query("SELECT mf.songId FROM MusicFeedback mf WHERE mf.userId = :userId AND mf.emotion = :emotion AND mf.feedback = :feedback")
    List<String> findSongIdsByUserIdAndEmotionAndFeedback(@Param("userId") Long userId, @Param("emotion") String emotion, @Param("feedback") String feedback);

    @Query("SELECT f.songId FROM MusicFeedback f WHERE f.userId = :userId AND f.feedback = 'like'")
    List<String> findLikedSongsByUserId(@Param("userId") Long userId);

    // 🔥 Add this to fetch all feedbacks by user (newest first)
    @Query("SELECT mf FROM MusicFeedback mf WHERE mf.userId = :userId ORDER BY mf.timestamp DESC")
    List<MusicFeedback> findLatestFeedbacksByUserId(@Param("userId") Long userId);

    List<MusicFeedback> findByUserIdAndEmotionAndFeedback(Long userId, String emotion, String feedback);
    List<MusicFeedback> findByUserIdAndEmotionAndFeedbackNot(Long userId, String emotion, String feedback);
    List<MusicFeedback> findByUserIdAndEmotion(Long userId, String emotion);
    List<MusicFeedback> findByUserId(Long userId);
    List<MusicFeedback> findByUserIdAndEmotionOrderByTimestampDesc(Long userId, String emotion);
}
