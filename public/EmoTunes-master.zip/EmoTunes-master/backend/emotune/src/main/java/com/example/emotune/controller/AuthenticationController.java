package com.example.emotune.controller;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.emotune.dto.LoginUserDto;
import com.example.emotune.dto.RegisterUserDto;
import com.example.emotune.dto.VerifyUserDto;
import com.example.emotune.model.User;
import com.example.emotune.responses.LoginResponse;
import com.example.emotune.service.AuthenticationService;
import com.example.emotune.service.JwtService;

@RequestMapping("/auth")
@RestController
public class AuthenticationController {
    private final JwtService jwtService;

    private final AuthenticationService authenticationService;

    public AuthenticationController(JwtService jwtService, AuthenticationService authenticationService) {
        this.jwtService = jwtService;
        this.authenticationService = authenticationService;
    }

@PostMapping("/signup")
public ResponseEntity<?> register(@RequestBody RegisterUserDto registerUserDto) {
    System.out.println("📩 Hit /auth/signup");
    System.out.println("📧 Email: " + registerUserDto.getEmail());
    System.out.println("👤 Username: " + registerUserDto.getUsername());

    try {
        User registeredUser = authenticationService.signup(registerUserDto);

        System.out.println("✅ User saved successfully: " + registeredUser.getEmail());

        return ResponseEntity.ok(Map.of(
            "message", "Verification code sent",
            "email", registeredUser.getEmail()
        ));
    } catch (Exception e) {
        System.out.println("❌ Error during signup: " + e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Signup failed: " + e.getMessage());
    }
}
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> authenticate(@RequestBody LoginUserDto loginUserDto){
        User authenticatedUser = authenticationService.authenticate(loginUserDto);
        String jwtToken = jwtService.generateToken(authenticatedUser);
        LoginResponse loginResponse = new LoginResponse(jwtToken, jwtService.getExpirationTime(), authenticatedUser.getId());
        return ResponseEntity.ok(loginResponse);
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyUser(@RequestBody VerifyUserDto verifyUserDto) {
        try {
            authenticationService.verifyUser(verifyUserDto);
            return ResponseEntity.ok("Account verified successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/resend")
    public ResponseEntity<?> resendVerificationCode(@RequestParam String email) {
        try {
            authenticationService.resendVerificationCode(email);
            return ResponseEntity.ok("Verification code sent");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}