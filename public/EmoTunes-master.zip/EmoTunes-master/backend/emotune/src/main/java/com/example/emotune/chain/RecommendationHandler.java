package com.example.emotune.chain;

import java.util.List;

public abstract class RecommendationHandler {
    protected RecommendationHandler next;

    public RecommendationHandler setNext(RecommendationHandler next) {
        this.next = next;
        return next;
    }

    public List<String> handle(List<String> recommendations, Long userId, String emotion) {
        List<String> processed = process(recommendations, userId, emotion);
        if (next != null) {
            return next.handle(processed, userId, emotion);
        }
        return processed;
    }

    protected abstract List<String> process(List<String> recommendations, Long userId, String emotion);
}
