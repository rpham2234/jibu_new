package com.example.emotune.template;

import com.example.emotune.chain.RecommendationChainBuilder;
import com.example.emotune.chain.RecommendationHandler;
import com.example.emotune.state.DefaultState;
import com.example.emotune.state.PersonalizedState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MusicRecommendationTemplate extends RecommendationTemplate {

    private final DefaultState defaultState;
    private final PersonalizedState personalizedState;
    private final RecommendationChainBuilder chainBuilder;

    @Autowired
    public MusicRecommendationTemplate(DefaultState defaultState,
                                       PersonalizedState personalizedState,
                                       RecommendationChainBuilder chainBuilder) {
        this.defaultState = defaultState;
        this.personalizedState = personalizedState;
        this.chainBuilder = chainBuilder;
    }

    @Override
    protected List<String> fetchRecommendations(Long userId, String emotion, String mode) {
        if ("personalized".equalsIgnoreCase(mode)) {
            return personalizedState.recommend(userId, emotion);
        } else {
            return defaultState.recommend(userId, emotion);
        }
    }

    @Override
    protected List<String> applyFilters(List<String> recommendations, Long userId, String emotion) {
        RecommendationHandler head = chainBuilder.buildChain();
        return head.handle(recommendations, userId, emotion);
    }
}
