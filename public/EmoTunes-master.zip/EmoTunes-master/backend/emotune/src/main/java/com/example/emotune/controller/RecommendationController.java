package com.example.emotune.controller;

import com.example.emotune.decorator.Recommendation;
import com.example.emotune.dto.MusicFeedbackRequest;
import com.example.emotune.memento.FeedbackMemento;
import com.example.emotune.model.MusicFeedback;
import com.example.emotune.service.music.SpotifyMusicAdapter;
import com.example.emotune.facade.RecommendationFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import com.example.emotune.bridge.*;
import com.example.emotune.model.MusicFeedback;


import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/recommend")
public class RecommendationController {

    private final RecommendationFacade recommendationFacade;
    private final com.example.emotune.service.music.MusicRecommendationService recommendationService; // Needed for userId
    private final MusicRecommendationImplementor musicImplementor;
    private final ActivityRecommendationImplementor activityImplementor;

    public RecommendationController(
            RecommendationFacade recommendationFacade,
            com.example.emotune.service.music.MusicRecommendationService recommendationService,
            MusicRecommendationImplementor musicImplementor,
            ActivityRecommendationImplementor activityImplementor
    ) {
        this.recommendationFacade = recommendationFacade;
        this.recommendationService = recommendationService;
        this.musicImplementor = musicImplementor;
        this.activityImplementor = activityImplementor;
    }
    
    // Music from DB (personalized/global)
    @GetMapping("/music")
    public ResponseEntity<List<String>> recommendMusic(
            @RequestParam String emotion,
            @RequestParam(defaultValue = "default") String mode,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        Long userId = recommendationService.getUserIdFromUserDetails(userDetails);
        List<String> songs = recommendationFacade.recommendMusic(userId, emotion, mode);
        System.out.println("Controller response: " + songs);
        return ResponseEntity.ok(songs);
    }

@GetMapping("/map")
public ResponseEntity<List<String>> getLikedSongs(
        @AuthenticationPrincipal UserDetails userDetails
) {
    if (userDetails == null) {
        return ResponseEntity.status(401).build();
    }

    Long userId = recommendationService.getUserIdFromUserDetails(userDetails);
    List<String> likedSongs = recommendationService.getLikedSongsForUser(userId);
    return ResponseEntity.ok(likedSongs);
}

    // Real-time from Spotify API (no personalization)
    @GetMapping("/music-api")
    public ResponseEntity<List<Map<String, String>>> recommendMusicFromApi(
            @RequestParam String emotion
    ) {
        List<Map<String, String>> songs = recommendationFacade.recommendMusicFromApi(emotion);
        return ResponseEntity.ok(songs);
    }


    // Submit feedback
    @PostMapping("/music/feedback")
    public ResponseEntity<String> submitMusicFeedback(
            @RequestBody MusicFeedbackRequest request,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        recommendationFacade.submitFeedback(request, userDetails);
        return ResponseEntity.ok("Feedback saved successfully! (Observers notified, check logs)");
    }

    // Undo feedback (Memento)
    @PostMapping("/music/feedback/undo-memento")
    public ResponseEntity<?> undoLastFeedbackMemento(
            @RequestParam String emotion,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        Long userId = recommendationService.getUserIdFromUserDetails(userDetails);
        FeedbackMemento memento = recommendationService.undoLastFeedbackMemento(userId, emotion);
        System.out.println("memento: " + memento);
        if (memento != null) {
            return ResponseEntity.ok(
                    new MementoRestoreResponse(
                            memento.getLikedSongs(),
                            memento.getDislikedSongs(),
                            "Restored previous feedback state for emotion: " + emotion
                    )
            );
        } else {
            return ResponseEntity.ok(
                    new MementoRestoreResponse(
                            List.of(),
                            List.of(),
                            "No previous feedback state to restore!"
                    )
            );
        }
    }

    // DTO to show what was restored
    public static class MementoRestoreResponse {
        public List<String> likedSongs;
        public List<String> dislikedSongs;
        public String message;

        public MementoRestoreResponse(List<String> liked, List<String> disliked, String message) {
            this.likedSongs = liked;
            this.dislikedSongs = disliked;
            this.message = message;
        }
    }




    // Decorated recommendation
    @GetMapping("/music-decorated")
    public ResponseEntity<?> recommendMusicDecorated(
            @RequestParam String emotion,
            @RequestParam(defaultValue = "default") String mode,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        Long userId = recommendationService.getUserIdFromUserDetails(userDetails);
        Recommendation decorated = recommendationFacade.getDecoratedRecommendation(userId, emotion, mode);
        return ResponseEntity.ok(
                new DecoratedMusicResponse(decorated.getSongs(), decorated.getDescription())
        );
    }

    static class DecoratedMusicResponse {
        public List<String> songs;
        public String description;

        public DecoratedMusicResponse(List<String> songs, String description) {
            this.songs = songs;
            this.description = description;
        }
    }

    // Bundle: Music + Activities
    @GetMapping("/bundle")
    public ResponseEntity<RecommendationFacade.BundleResponse> recommendBundle(
            @RequestParam String emotion,
            @RequestParam(defaultValue = "default") String mode,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        Long userId = recommendationService.getUserIdFromUserDetails(userDetails);
        RecommendationFacade.BundleResponse resp = recommendationFacade.recommendBundle(userId, emotion, mode);
        return ResponseEntity.ok(resp);
    }

    // In RecommendationController.java (relevant method)
    @GetMapping("/bridge/music")
    public ResponseEntity<List<String>> recommendMusicViaBridge(
            @RequestParam String emotion,
            @RequestParam(defaultValue = "default") String mode,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        Long userId = recommendationService.getUserIdFromUserDetails(userDetails);
        RecommendationBridge bridge = new MusicRecommendationBridge(musicImplementor);
        List<String> songs = bridge.getRecommendations(userId, emotion, mode);
        return ResponseEntity.ok(songs);
    }

    @GetMapping("/bridge/activity")
    public ResponseEntity<List<String>> recommendActivityViaBridge(
            @RequestParam String emotion,
            @RequestParam(defaultValue = "default") String mode,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        Long userId = recommendationService.getUserIdFromUserDetails(userDetails);
        RecommendationBridge bridge = new ActivityRecommendationBridge(activityImplementor);
        List<String> activities = bridge.getRecommendations(userId, emotion, mode);
        return ResponseEntity.ok(activities);
    }

    @GetMapping("/bundle-composite")
    public ResponseEntity<CompositeBundleResponse> recommendBundleComposite(
            @RequestParam String emotion,
            @RequestParam(defaultValue = "default") String mode,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        Long userId = recommendationService.getUserIdFromUserDetails(userDetails);
        // Directly get composite from template
        Recommendation composite = recommendationFacade.getCombinedTemplate().recommendBundle(userId, emotion, mode);
        // You can split the songs if you want, or just show all
        return ResponseEntity.ok(new CompositeBundleResponse(composite.getSongs(), composite.getDescription()));
    }

    // Helper DTO
    static class CompositeBundleResponse {
        public List<String> allRecommendations;
        public String description;

        public CompositeBundleResponse(List<String> allRecommendations, String description) {
            this.allRecommendations = allRecommendations;
            this.description = description;
        }
    }
    @GetMapping("/feedback-search")
    public ResponseEntity<List<MusicFeedback>> searchFeedback(
            @RequestParam String query
    ) {
        List<MusicFeedback> result = recommendationService.searchFeedbackByQuery(query);
        return ResponseEntity.ok(result);
    }

}
