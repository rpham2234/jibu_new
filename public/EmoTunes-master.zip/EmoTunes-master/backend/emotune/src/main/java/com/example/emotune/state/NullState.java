package com.example.emotune.state;

import java.util.Collections;
import java.util.List;

public class NullState implements RecommendationState {
    @Override
    public List<String> recommend(Long userId, String emotion) {
        // Returns an empty recommendation list, but could also return a special message object if needed.
        return Collections.emptyList();
    }

    @Override
    public String getStateName() {
        return "NullState (No Recommendation)";
    }
}
