// src/main/java/com/example/emotune/builder/PlaylistBuilder.java
package com.example.emotune.builder;

import com.example.emotune.model.Playlist;
import java.util.ArrayList;
import java.util.List;

public class PlaylistBuilder {
    private String name;
    private Long userId;
    private List<String> songIds = new ArrayList<>();

    public PlaylistBuilder setName(String name) {
        this.name = name;
        return this;
    }

    public PlaylistBuilder setUserId(Long userId) {
        this.userId = userId;
        return this;
    }

    public PlaylistBuilder addSong(String songId) {
        this.songIds.add(songId);
        return this;
    }

    public PlaylistBuilder addSongs(List<String> songs) {
        this.songIds.addAll(songs);
        return this;
    }

    public Playlist build() {
        return Playlist.builder()
                .name(name)
                .userId(userId)
                .songIds(songIds)
                .build();
    }
}
