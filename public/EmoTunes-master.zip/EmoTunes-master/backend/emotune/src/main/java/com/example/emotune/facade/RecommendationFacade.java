package com.example.emotune.facade;

import com.example.emotune.decorator.Recommendation;
import com.example.emotune.dto.MusicFeedbackRequest;
import com.example.emotune.model.MusicFeedback;
import com.example.emotune.service.music.MusicRecommendationService;
import com.example.emotune.service.music.MusicRecommenderFactory;
import com.example.emotune.template.CombinedRecommendationTemplate;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class RecommendationFacade {

    private final MusicRecommendationService recommendationService;
    private final MusicRecommenderFactory musicRecommenderFactory;
    private final CombinedRecommendationTemplate combinedTemplate;

    public RecommendationFacade(
            MusicRecommendationService recommendationService,
            MusicRecommenderFactory musicRecommenderFactory,
            CombinedRecommendationTemplate combinedTemplate
    ) {
        this.recommendationService = recommendationService;
        this.musicRecommenderFactory = musicRecommenderFactory;
        this.combinedTemplate = combinedTemplate;
    }

    // For bundle-composite
    public CombinedRecommendationTemplate getCombinedTemplate() {
        return this.combinedTemplate;
    }

    // Music from DB (personalized/global)
    public List<String> recommendMusic(Long userId, String emotion, String mode) {
        System.out.println("Facade: Handling recommendMusic for userId=" + userId + ", emotion=" + emotion + ", mode=" + mode);
        return recommendationService.recommend(userId, emotion, mode);
    }

    // Music from Spotify API (no personalization) - UPDATED
    public List<Map<String, String>> recommendMusicFromApi(String emotion) {
        return musicRecommenderFactory.getRecommender().recommendMusic(emotion);
    }

    // Feedback submit
    public void submitFeedback(MusicFeedbackRequest request, UserDetails userDetails) {
        recommendationService.handleFeedback(request, userDetails);
    }

    // Feedback undo (memento)
    public MusicFeedback undoLastFeedback(String emotion, UserDetails userDetails) {
        return recommendationService.undoLastFeedbackAndReturn(emotion, userDetails);
    }

    // Decorated music recommendations
    public Recommendation getDecoratedRecommendation(Long userId, String emotion, String mode) {
        return recommendationService.getDecoratedRecommendation(userId, emotion, mode);
    }

    // Bundle recommendation (music + activity)
    public BundleResponse recommendBundle(Long userId, String emotion, String mode) {
        Recommendation decoratedMusic = combinedTemplate.recommendBundle(userId, emotion, mode);
        List<String> activities = combinedTemplate.activityTemplate.recommend(userId, emotion, mode);
        return new BundleResponse(decoratedMusic.getSongs(), decoratedMusic.getDescription(), activities);
    }

    // Response wrapper for /bundle
    public static class BundleResponse {
        public List<String> songs;
        public String description;
        public List<String> activities;

        public BundleResponse(List<String> songs, String description, List<String> activities) {
            this.songs = songs;
            this.description = description;
            this.activities = activities;
        }
    }
}
