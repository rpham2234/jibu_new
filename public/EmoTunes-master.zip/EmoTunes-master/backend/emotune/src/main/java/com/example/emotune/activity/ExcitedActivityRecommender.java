package com.example.emotune.activity;

import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.List;

@Component
public class ExcitedActivityRecommender implements ActivityRecommender {
    @Override
    public List<String> recommendActivity() {
        return Arrays.asList(
                "Plan a spontaneous road trip",
                "Learn a fun new skill online",
                "Share your excitement with friends"
        );
    }
}
