package com.example.emotune.service.music;

import com.example.emotune.dto.MusicFeedbackRequest;
import com.example.emotune.model.MusicFeedback;
import com.example.emotune.repository.MusicFeedbackRepository;
import com.example.emotune.repository.UserRepository;
import com.example.emotune.state.*;
import com.example.emotune.memento.FeedbackCaretaker;
import com.example.emotune.memento.FeedbackMemento;
import com.example.emotune.command.FeedbackCommand;
import com.example.emotune.command.FeedbackInvoker;
import com.example.emotune.command.SaveFeedbackCommand;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.emotune.decorator.BasicRecommendation;
import com.example.emotune.decorator.EmojiRecommendationDecorator;
import com.example.emotune.decorator.Recommendation;
import com.example.emotune.observer.FeedbackObserver;
import com.example.emotune.interpreter.FeedbackInterpreterParser;
import com.example.emotune.interpreter.InterpreterExpression;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MusicRecommendationService {
    private final MusicFeedbackRepository feedbackRepo;
    private final UserRepository userRepo;
    private final DefaultState defaultState;
    private final PersonalizedState personalizedState;
    private final List<FeedbackObserver> observers;



    // --- Memento Caretaker ---
    private final FeedbackCaretaker caretaker = new FeedbackCaretaker();

    @Autowired
    public MusicRecommendationService(
            MusicFeedbackRepository feedbackRepo,
            UserRepository userRepo,
            DefaultState defaultState,
            PersonalizedState personalizedState,
            List<FeedbackObserver> observers
    ) {
        this.feedbackRepo = feedbackRepo;
        this.userRepo = userRepo;
        this.defaultState = defaultState;
        this.personalizedState = personalizedState;
        this.observers = observers;
    }
    public UserRepository getUserRepository() {
        return userRepo;
    }
    
public List<String> getLikedSongsForUser(Long userId) {
    List<MusicFeedback> allLatest = feedbackRepo.findLatestFeedbacksByUserId(userId);
    return allLatest.stream()
        .filter(fb -> fb.getFeedback().equalsIgnoreCase("like"))
        .map(MusicFeedback::getSongId)
        .toList();
}

    private void notifyObservers(MusicFeedback feedback) {
        for (FeedbackObserver observer : observers) {
            observer.onFeedbackSubmitted(feedback);
        }
    }

    // Helper for extracting userId from UserDetails
    public Long getUserIdFromUserDetails(UserDetails userDetails) {
        String username = userDetails.getUsername();
        return userRepo.findByEmail(username)
                .map(user -> user.getId()) 
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    // Recommend music using State pattern (mode: "default" or "personalized")
    public List<String> recommend(Long userId, String emotion, String mode) {
        RecommendationContext context = new RecommendationContext();
        if ("personalized".equalsIgnoreCase(mode)) {
            context.setState(personalizedState);
        } else if ("default".equalsIgnoreCase(mode)) {
            context.setState(defaultState);
        } else {
            // Set to NullState for unknown/unsupported modes (no error thrown, just empty)
            context.setState(null); // Will default to NullState!
        }
        return context.recommend(userId, emotion);
    }


    // Save feedback (Memento pattern: save state before saving feedback)
    public void handleFeedback(MusicFeedbackRequest request, UserDetails userDetails) {
    System.out.println("Received feedback: " + request.getFeedback() + " for " + request.getSongId());
    String username = userDetails.getUsername();
    var user = userRepo.findByEmail(username)
            .orElseThrow(() -> new RuntimeException("User not found"));

    // Save memento state
    List<String> prevLiked = feedbackRepo.findSongIdsByUserIdAndEmotionAndFeedback(user.getId(), request.getEmotion(), "like");
    List<String> prevDisliked = feedbackRepo.findSongIdsByUserIdAndEmotionAndFeedback(user.getId(), request.getEmotion(), "dislike");
    FeedbackMemento memento = new FeedbackMemento(prevLiked, prevDisliked);
    caretaker.saveState(memento);

    FeedbackContext feedbackContext = new FeedbackContext();
    if ("like".equalsIgnoreCase(request.getFeedback())) {
        feedbackContext.setState(new LikeState());
    } else if ("dislike".equalsIgnoreCase(request.getFeedback())) {
        feedbackContext.setState(new DislikeState());
    } else {
        throw new IllegalArgumentException("Unknown feedback type: " + request.getFeedback());
    }

    String feedbackLabel = feedbackContext.handleFeedback(request.getFeedback());

    MusicFeedback feedback = MusicFeedback.builder()
            .userId(user.getId())
            .songId(request.getSongId())  // Already in full format
            .emotion(request.getEmotion())
            .feedback(request.getFeedback())
            .timestamp(LocalDateTime.now())
            .build();

    FeedbackCommand command = new SaveFeedbackCommand(feedbackRepo, feedback);
    FeedbackInvoker invoker = new FeedbackInvoker();
    invoker.setCommand(command);
    invoker.submit();

    notifyObservers(feedback);
}

    // --- Memento: Restore previous state (UNDO) ---
    public FeedbackMemento undoLastFeedbackMemento(Long userId, String emotion) {
        FeedbackMemento memento = caretaker.restoreState();
        if (memento == null) return null;


        // Delete all current feedback for this emotion
        List<MusicFeedback> currentFeedback = feedbackRepo.findByUserIdAndEmotion(userId, emotion);
        feedbackRepo.deleteAll(currentFeedback);
        System.out.println("Deleting feedback for user: " + userId + ", emotion: " + emotion);
        System.out.println("Current feedback count: " + currentFeedback.size());

        // Restore liked
        for (String songId : memento.getLikedSongs()) {
            MusicFeedback feedback = MusicFeedback.builder()
                    .userId(userId).songId(songId).emotion(emotion)
                    .feedback("like").timestamp(LocalDateTime.now()).build();
            feedbackRepo.save(feedback);
        }
        // Restore disliked
        for (String songId : memento.getDislikedSongs()) {
            MusicFeedback feedback = MusicFeedback.builder()
                    .userId(userId).songId(songId).emotion(emotion)
                    .feedback("dislike").timestamp(LocalDateTime.now()).build();
            feedbackRepo.save(feedback);
        }

        return memento; // <--- Return the restored state
    }


    public MusicFeedback undoLastFeedbackAndReturn(String emotion, UserDetails userDetails) {
        String username = userDetails.getUsername();
        var user = userRepo.findByEmail(username)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Long userId = user.getId();

        // Find last feedback for this user & emotion, ordered by timestamp DESC
        List<MusicFeedback> feedbacks = feedbackRepo.findByUserIdAndEmotionOrderByTimestampDesc(userId, emotion);
        if (feedbacks.isEmpty()) return null;

        MusicFeedback last = feedbacks.get(0);
        feedbackRepo.deleteById(last.getId());
        return last;
    }

    public Recommendation getDecoratedRecommendation(Long userId, String emotion, String mode) {
        // Get songs using your existing logic
        List<String> songs = recommend(userId, emotion, mode);
        BasicRecommendation base = new BasicRecommendation(songs);
        return new EmojiRecommendationDecorator(base, emotion);
    }

    public List<MusicFeedback> searchFeedbackByQuery(String query) {
        // Pull all feedback from DB
        List<MusicFeedback> allFeedback = feedbackRepo.findAll();
        InterpreterExpression expr = FeedbackInterpreterParser.parse(query);
        return expr.interpret(allFeedback);
    }
}
