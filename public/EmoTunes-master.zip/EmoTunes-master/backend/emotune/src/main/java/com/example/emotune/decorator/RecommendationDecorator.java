// src/main/java/com/example/emotune/decorator/RecommendationDecorator.java
package com.example.emotune.decorator;

import java.util.List;

public abstract class RecommendationDecorator implements Recommendation {
    protected final Recommendation decorated;

    public RecommendationDecorator(Recommendation decorated) {
        this.decorated = decorated;
    }

    @Override
    public List<String> getSongs() {
        return decorated.getSongs();
    }

    @Override
    public String getDescription() {
        return decorated.getDescription();
    }
}
