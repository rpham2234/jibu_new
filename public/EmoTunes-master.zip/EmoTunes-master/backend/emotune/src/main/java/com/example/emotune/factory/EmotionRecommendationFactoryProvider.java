package com.example.emotune.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class EmotionRecommendationFactoryProvider {

    private final ApplicationContext context;

    @Autowired
    public EmotionRecommendationFactoryProvider(ApplicationContext context) {
        this.context = context;
    }

    public EmotionRecommendationFactory getFactory(String emotion) {
        String beanName = emotion.trim().toLowerCase() + "RecommendationFactory";
        if (!context.containsBean(beanName)) {
            throw new RuntimeException("No RecommendationFactory found for emotion: " + emotion);
        }
        return context.getBean(beanName, EmotionRecommendationFactory.class);
    }
}
