package com.example.emotune.chain;

import com.example.emotune.repository.MusicFeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class FeedbackFilterHandler extends RecommendationHandler {

    private final MusicFeedbackRepository feedbackRepo;

    @Autowired
    public FeedbackFilterHandler(MusicFeedbackRepository feedbackRepo) {
        this.feedbackRepo = feedbackRepo;
    }

    @Override
    protected List<String> process(List<String> recommendations, Long userId, String emotion) {
        List<String> disliked = feedbackRepo.findSongIdsByUserIdAndEmotionAndFeedback(userId, emotion, "dislike");
        recommendations.removeAll(disliked);
        return recommendations;
    }
}
