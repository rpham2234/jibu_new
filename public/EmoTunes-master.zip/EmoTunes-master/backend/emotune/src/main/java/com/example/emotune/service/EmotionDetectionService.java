package com.example.emotune.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class EmotionDetectionService {
    private final EmotionDetectionStrategy emotionDetectionStrategy;

    // Use @Qualifier to switch between strategies
    public EmotionDetectionService(@Qualifier("llmStrategy") EmotionDetectionStrategy strategy) {
        this.emotionDetectionStrategy = strategy;
    }

    public String detectEmotion(MultipartFile image) {
        return emotionDetectionStrategy.detectEmotion(image);
    }
}
