package com.example.emotune.state;

import com.example.emotune.chain.RecommendationChainBuilder;
import com.example.emotune.chain.RecommendationHandler;
import com.example.emotune.repository.MusicFeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DefaultState implements RecommendationState {

    private final MusicFeedbackRepository feedbackRepo;
    private final RecommendationChainBuilder chainBuilder;

    @Autowired
    public DefaultState(MusicFeedbackRepository feedbackRepo,
                        RecommendationChainBuilder chainBuilder) {
        this.feedbackRepo = feedbackRepo;
        this.chainBuilder = chainBuilder;
    }

    @Override
    public List<String> recommend(Long userId, String emotion) {
        List<String> mostLiked = feedbackRepo.findMostLikedSongIdsByEmotion(emotion);
        RecommendationHandler head = chainBuilder.buildChain();
        return head.handle(mostLiked, userId, emotion);
    }

    @Override
    public String getStateName() {
        return "Default (Global Popular)";
    }
}
