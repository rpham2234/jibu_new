package com.example.emotune.chain;

import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class DuplicateFilterHandler extends RecommendationHandler {

    @Override
    protected List<String> process(List<String> recommendations, Long userId, String emotion) {
        Set<String> seen = new HashSet<>();
        List<String> unique = new ArrayList<>();
        for (String rec : recommendations) {
            if (!seen.contains(rec)) {
                unique.add(rec);
                seen.add(rec);
            }
        }
        return unique;
    }
}
