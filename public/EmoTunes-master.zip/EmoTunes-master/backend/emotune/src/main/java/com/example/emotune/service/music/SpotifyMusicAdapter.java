package com.example.emotune.service.music;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.*;

@Component("spotifyMusicAdapter")
public class SpotifyMusicAdapter implements MusicRecommender {

    private final SpotifyAuthService spotifyAuthService;
    private final WebClient webClient;

    // Dependency injection of SpotifyAuthService
    public SpotifyMusicAdapter(SpotifyAuthService spotifyAuthService) {
        this.spotifyAuthService = spotifyAuthService;
        this.webClient = WebClient
                .builder()
                .baseUrl("https://api.spotify.com/v1")
                .build();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Map<String, String>> recommendMusic(String emotion) {
        String accessToken = spotifyAuthService.getAccessToken();
        if (accessToken == null) {
            System.err.println("No access token available from SpotifyAuthService!");
            return Collections.emptyList();
        }

        String query = emotion + " songs";
        System.out.println("SpotifyMusicAdapter: Query = " + query);

        Map<String, Object> response = webClient.get()
                .uri(uri -> uri
                        .path("/search")
                        .queryParam("q", query)
                        .queryParam("type", "track")
                        .queryParam("limit", 10)
                        .build())
                .header("Authorization", "Bearer " + accessToken)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                .block();

        if (response == null || !response.containsKey("tracks")) {
            return Collections.emptyList();
        }

        Map<String, Object> tracks = (Map<String, Object>) response.get("tracks");
        List<Map<String, Object>> items = (List<Map<String, Object>>) tracks.get("items");
        List<Map<String, String>> result = new ArrayList<>();

        if (items != null) {
            for (Map<String, Object> item : items) {
                Map<String, String> song = new HashMap<>();
                song.put("name", (String) item.get("name"));
                // Get first artist
                List<Map<String, Object>> artists = (List<Map<String, Object>>) item.get("artists");
                song.put("artist", artists.get(0).get("name").toString());
                // Album name
                Map<String, Object> album = (Map<String, Object>) item.get("album");
                song.put("album", album.get("name").toString());
                // Spotify URL
                Map<String, Object> external_urls = (Map<String, Object>) item.get("external_urls");
                song.put("url", external_urls.get("spotify").toString());
                // Optionally preview_url
                if (item.containsKey("preview_url") && item.get("preview_url") != null) {
                    song.put("preview_url", item.get("preview_url").toString());
                }
                result.add(song);
            }
        }
        System.out.println("Returning formatted song list: " + result);
        return result;
    }

    // Optional: Track details by ID
    public Map<String, Object> getTrackDetails(String trackId) {
        System.out.println("SpotifyMusicAdapter: getTrackDetails called with ID = " + trackId);

        String token = spotifyAuthService.getAccessToken();
        if (token == null) {
            System.out.println("SpotifyMusicAdapter: No token for track details");
            return Map.of();
        }

        Map<String, Object> response = webClient.get()
                .uri("/tracks/" + trackId)
                .header("Authorization", "Bearer " + token)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                .block();

        System.out.println("SpotifyMusicAdapter: Track details = " + response);
        return response != null ? response : Map.of();
    }
}
