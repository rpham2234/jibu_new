package com.example.emotune.template;

import java.util.List;

public abstract class RecommendationTemplate {

    public final List<String> recommend(Long userId, String emotion, String mode) {
        List<String> raw = fetchRecommendations(userId, emotion, mode);
        List<String> filtered = applyFilters(raw, userId, emotion);
        List<String> decorated = applyDecorators(filtered, emotion);
        return decorated;
    }

    protected abstract List<String> fetchRecommendations(Long userId, String emotion, String mode);

    protected List<String> applyFilters(List<String> recommendations, Long userId, String emotion) {
        return recommendations;
    }

    protected List<String> applyDecorators(List<String> recommendations, String emotion) {
        return recommendations;
    }
}
