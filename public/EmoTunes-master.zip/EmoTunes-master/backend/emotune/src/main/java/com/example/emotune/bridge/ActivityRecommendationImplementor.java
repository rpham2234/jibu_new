package com.example.emotune.bridge;

import org.springframework.stereotype.Component;
import java.util.List;
import java.util.Map;

@Component
public class ActivityRecommendationImplementor implements RecommendationImplementor {

    private final Map<String, List<String>> activitiesByEmotion = Map.of(
            "happy", List.of("Go for a walk", "Call a friend", "Dance"),
            "sad", List.of("Journal", "Meditate", "Listen to calming music"),
            "angry", List.of("Exercise", "Deep breathing", "Write out your feelings"),
            "excited", List.of("Plan a trip", "Start a creative project", "Celebrate"),
            "surprised", List.of("Share with someone", "Reflect", "Capture the moment"),
            "neutral", List.of("Read a book", "Explore something new", "Relax")
    );

    @Override
    public List<String> recommend(Long userId, String emotion, String mode) {
        return activitiesByEmotion.getOrDefault(emotion.toLowerCase(), List.of("Try a new activity", "Take a deep breath"));
    }

    @Override
    public String getType() {
        return "Activity";
    }
}
