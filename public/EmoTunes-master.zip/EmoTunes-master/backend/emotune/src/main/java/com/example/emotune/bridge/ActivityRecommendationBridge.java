package com.example.emotune.bridge;

import java.util.List;

public class ActivityRecommendationBridge extends RecommendationBridge {
    public ActivityRecommendationBridge(RecommendationImplementor implementor) {
        super(implementor);
    }

    @Override
    public List<String> getRecommendations(Long userId, String emotion, String mode) {
        return implementor.recommend(userId, emotion, mode);
    }
}
