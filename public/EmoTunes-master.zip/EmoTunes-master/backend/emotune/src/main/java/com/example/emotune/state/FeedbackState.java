package com.example.emotune.state;

public interface FeedbackState {
    String handle(String feedback); // e.g., return "Positive", "Negative", etc.
}
