package com.example.emotune.activity;

import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.List;

@Component
public class HappyActivityRecommender implements ActivityRecommender {
    @Override
    public List<String> recommendActivity() {
        return Arrays.asList(
                "Dance to your favorite song",
                "Go for a celebration meal",
                "Share your joy on social media"
        );
    }
}
