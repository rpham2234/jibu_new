package com.example.emotune.state;

import lombok.Setter;

@Setter
public class FeedbackContext {
    private FeedbackState state;

    public String handleFeedback(String feedback) {
        if (state == null) {
            throw new IllegalStateException("Feedback state not set!");
        }
        return state.handle(feedback);
    }
}
