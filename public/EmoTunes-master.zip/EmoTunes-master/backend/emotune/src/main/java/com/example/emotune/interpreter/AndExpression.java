package com.example.emotune.interpreter;

import com.example.emotune.model.MusicFeedback;
import java.util.List;

public class AndExpression implements InterpreterExpression {
    private final InterpreterExpression left, right;

    public AndExpression(InterpreterExpression left, InterpreterExpression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public List<MusicFeedback> interpret(List<MusicFeedback> feedbackList) {
        List<MusicFeedback> leftResult = left.interpret(feedbackList);
        return right.interpret(leftResult); // AND = filter left then right
    }
}
