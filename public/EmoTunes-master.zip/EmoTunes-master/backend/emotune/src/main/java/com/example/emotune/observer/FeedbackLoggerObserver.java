// src/main/java/com/example/emotune/observer/FeedbackLoggerObserver.java
package com.example.emotune.observer;

import com.example.emotune.model.MusicFeedback;
import org.springframework.stereotype.Component;

@Component
public class FeedbackLoggerObserver implements FeedbackObserver {
    @Override
    public void onFeedbackSubmitted(MusicFeedback feedback) {
        System.out.println("Observer: FeedbackLoggerObserver notified! Feedback: " + feedback);
    }
}
