package com.example.emotune.service.music;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Base64;
import java.util.Map;

@Service
public class SpotifyAuthService {
    private static SpotifyAuthService instance;
    private String clientId;
    private String clientSecret;
    private final WebClient webClient = WebClient.create("https://accounts.spotify.com/api");

    // Private constructor prevents instantiation from outside
    private SpotifyAuthService() {}

    // Static method for getting the singleton instance
    public static SpotifyAuthService getInstance() {
        if (instance == null) {
            instance = new SpotifyAuthService();
        }
        return instance;
    }

    public void setConfig(String clientId, String clientSecret) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }

    public String getAccessToken() {
        if (clientId == null || clientSecret == null) {
            System.err.println("SpotifyAuthService: clientId or clientSecret not configured!");
            return null;
        }

        String auth = clientId + ":" + clientSecret;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());

        try {
            String token = webClient.post()
                    .uri("/token")
                    .header("Authorization", "Basic " + encodedAuth)
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .bodyValue("grant_type=client_credentials")
                    .retrieve()
                    .bodyToMono(Map.class)
                    .map(response -> (String) response.get("access_token"))
                    .block();
            System.out.println("SpotifyAuthService: Access token = " + token);
            return token;
        } catch (Exception e) {
            System.err.println("SpotifyAuthService: ERROR getting token!");
            e.printStackTrace();
            return null;
        }
    }
}
