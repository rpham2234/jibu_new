package com.example.emotune.service.music;

import com.example.emotune.state.RecommendationState;
import com.example.emotune.state.NullState;

import java.util.List;

public class RecommendationContext {
    private RecommendationState state = new NullState(); // Default to NullState

    public void setState(RecommendationState state) {
        this.state = state != null ? state : new NullState();
    }

    public List<String> recommend(Long userId, String emotion) {
        // Always safe: state is never null
        return state.recommend(userId, emotion);
    }

    public String getMode() {
        return state == null ? "None" : state.getStateName();
    }
}
