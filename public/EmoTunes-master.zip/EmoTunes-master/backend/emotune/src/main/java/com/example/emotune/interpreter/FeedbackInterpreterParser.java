package com.example.emotune.interpreter;

import java.util.Stack;

public class FeedbackInterpreterParser {
    // Supports queries like: emotion=happy AND feedback=like OR emotion=sad
    public static InterpreterExpression parse(String query) {
        // Very basic parser, can be extended (for demo: supports only AND/OR, not parenthesis)
        // Split on AND/OR, build left-right tree
        String upper = query.toUpperCase();
        if (upper.contains(" AND ")) {
            String[] parts = upper.split(" AND ", 2);
            return new AndExpression(
                    parse(parts[0].trim()),
                    parse(parts[1].trim())
            );
        }
        if (upper.contains(" OR ")) {
            String[] parts = upper.split(" OR ", 2);
            return new OrExpression(
                    parse(parts[0].trim()),
                    parse(parts[1].trim())
            );
        }
        // Terminal: field=value
        String[] keyval = query.split("=", 2);
        if (keyval.length == 2) {
            return new TerminalExpression(keyval[0].trim(), keyval[1].trim());
        }
        throw new IllegalArgumentException("Invalid query: " + query);
    }
}
