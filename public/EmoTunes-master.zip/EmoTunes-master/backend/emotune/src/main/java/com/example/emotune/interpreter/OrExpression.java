package com.example.emotune.interpreter;

import com.example.emotune.model.MusicFeedback;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OrExpression implements InterpreterExpression {
    private final InterpreterExpression left, right;

    public OrExpression(InterpreterExpression left, InterpreterExpression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public List<MusicFeedback> interpret(List<MusicFeedback> feedbackList) {
        List<MusicFeedback> leftResult = left.interpret(feedbackList);
        List<MusicFeedback> rightResult = right.interpret(feedbackList);

        // Combine and remove duplicates
        return Stream.concat(leftResult.stream(), rightResult.stream())
                .distinct()
                .collect(Collectors.toList());
    }
}
