package com.example.emotune.activity;

import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.List;

@Component
public class SurprisedActivityRecommender implements ActivityRecommender {
    @Override
    public List<String> recommendActivity() {
        return Arrays.asList(
                "Write down what surprised you",
                "Explore a new hobby online",
                "Share the moment with others"
        );
    }
}
