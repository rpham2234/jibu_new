package com.example.emotune.factory;

import com.example.emotune.service.music.MusicRecommender;
import com.example.emotune.activity.ActivityRecommender;

public interface EmotionRecommendationFactory {
    MusicRecommender createMusicRecommender();
    ActivityRecommender createActivityRecommender();
}
