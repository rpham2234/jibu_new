// src/main/java/com/example/emotune/decorator/EmojiRecommendationDecorator.java
package com.example.emotune.decorator;

import java.util.List;
import java.util.stream.Collectors;

public class EmojiRecommendationDecorator extends RecommendationDecorator {
    private final String emotion;

    public EmojiRecommendationDecorator(Recommendation decorated, String emotion) {
        super(decorated);
        this.emotion = emotion;
    }

    @Override
    public List<String> getSongs() {
        // Add emoji to every song title!
        String emoji = mapEmotionToEmoji(emotion);
        return decorated.getSongs().stream()
                .map(song -> song + " " + emoji)
                .collect(Collectors.toList());
    }

    @Override
    public String getDescription() {
        return decorated.getDescription() + " (with emoji: " + mapEmotionToEmoji(emotion) + ")";
    }

    private String mapEmotionToEmoji(String emotion) {
        return switch (emotion.toLowerCase()) {
            case "happy" -> "😄";
            case "sad" -> "😢";
            case "angry" -> "😡";
            case "excited" -> "🤩";
            case "surprised" -> "😲";
            case "neutral" -> "😐";
            default -> "";
        };
    }
}
