package com.example.emotune.activity;

import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.List;

@Component
public class AngryActivityRecommender implements ActivityRecommender {
    @Override
    public List<String> recommendActivity() {
        return Arrays.asList(
                "Practice deep breathing exercises",
                "Do a short workout or punch a pillow",
                "Journal your thoughts"
        );
    }
}
