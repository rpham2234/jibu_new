package com.example.emotune.factory;

import com.example.emotune.service.music.MusicRecommender;
import com.example.emotune.service.music.SpotifyMusicAdapter;
import com.example.emotune.activity.ActivityRecommender;
import com.example.emotune.activity.ExcitedActivityRecommender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("excitedRecommendationFactory")
public class ExcitedRecommendationFactory implements EmotionRecommendationFactory {

    private final SpotifyMusicAdapter spotifyMusicAdapter;
    private final ExcitedActivityRecommender excitedActivityRecommender;

    @Autowired
    public ExcitedRecommendationFactory(SpotifyMusicAdapter spotifyMusicAdapter,
                                        ExcitedActivityRecommender excitedActivityRecommender) {
        this.spotifyMusicAdapter = spotifyMusicAdapter;
        this.excitedActivityRecommender = excitedActivityRecommender;
    }

    @Override
    public MusicRecommender createMusicRecommender() {
        return spotifyMusicAdapter;
    }

    @Override
    public ActivityRecommender createActivityRecommender() {
        return excitedActivityRecommender;
    }
}
