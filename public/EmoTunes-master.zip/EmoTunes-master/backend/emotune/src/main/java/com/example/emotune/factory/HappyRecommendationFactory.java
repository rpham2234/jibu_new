package com.example.emotune.factory;

import com.example.emotune.service.music.MusicRecommender;
import com.example.emotune.service.music.SpotifyMusicAdapter;
import com.example.emotune.activity.ActivityRecommender;
import com.example.emotune.activity.HappyActivityRecommender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("happyRecommendationFactory")
public class HappyRecommendationFactory implements EmotionRecommendationFactory {

    private final SpotifyMusicAdapter spotifyMusicAdapter;
    private final HappyActivityRecommender happyActivityRecommender;

    @Autowired
    public HappyRecommendationFactory(SpotifyMusicAdapter spotifyMusicAdapter,
                                      HappyActivityRecommender happyActivityRecommender) {
        this.spotifyMusicAdapter = spotifyMusicAdapter;
        this.happyActivityRecommender = happyActivityRecommender;
    }

    @Override
    public MusicRecommender createMusicRecommender() {
        return spotifyMusicAdapter;
    }

    @Override
    public ActivityRecommender createActivityRecommender() {
        return happyActivityRecommender;
    }
}
