package com.example.emotune.interpreter;

import com.example.emotune.model.MusicFeedback;
import java.util.List;

public interface InterpreterExpression {
    List<MusicFeedback> interpret(List<MusicFeedback> feedbackList);
}
