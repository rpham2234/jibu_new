package com.example.emotune.activity;

import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.List;

@Component
public class SadActivityRecommender implements ActivityRecommender {
    @Override
    public List<String> recommendActivity() {
        return Arrays.asList(
                "Watch a comedy movie",
                "Go for a walk in the park",
                "Call a close friend"
        );
    }
}
