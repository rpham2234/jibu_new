// src/main/java/com/example/emotune/command/FeedbackInvoker.java
package com.example.emotune.command;

public class FeedbackInvoker {
    private FeedbackCommand command;

    public void setCommand(FeedbackCommand command) {
        this.command = command;
    }

    public void submit() {
        if (command != null) command.execute();
    }
}
