package com.example.emotune.service;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.Random;

@Component("mlMockStrategy")
public class MLMockEmotionDetectionStrategy implements EmotionDetectionStrategy {
    private static final String[] EMOTIONS = {"happy", "sad", "angry", "excited", "surprised", "neutral"};

    @Override
    public String detectEmotion(MultipartFile image) {
        int idx = new Random().nextInt(EMOTIONS.length);
        return EMOTIONS[idx];
    }
}
