package com.example.emotune.service;

import org.springframework.web.multipart.MultipartFile;

public interface EmotionDetectionStrategy {
    String detectEmotion(MultipartFile image);
}
