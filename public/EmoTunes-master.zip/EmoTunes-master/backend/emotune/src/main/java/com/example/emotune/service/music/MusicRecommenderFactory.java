package com.example.emotune.service.music;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MusicRecommenderFactory {

    private final SpotifyApiProxy spotifyApiProxy;

    @Autowired
    public MusicRecommenderFactory(SpotifyApiProxy spotifyApiProxy) {
        this.spotifyApiProxy = spotifyApiProxy;
    }

    public MusicRecommender getRecommender() {
        // Return proxy instead of direct adapter
        return spotifyApiProxy;
    }
}
