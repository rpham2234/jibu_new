package com.example.emotune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class EmotuneApplication {

	public EmotuneApplication(
			@Value("${spotify.client.id}") String clientId,
			@Value("${spotify.client.secret}") String clientSecret
	) {
		// This block runs ONCE at app startup!
		com.example.emotune.service.music.SpotifyAuthService
				.getInstance()
				.setConfig(clientId, clientSecret);
		System.out.println("SpotifyAuthService Singleton configured at startup!");
	}
	public static void main(String[] args) {
		SpringApplication.run(EmotuneApplication.class, args);
	}

}