// src/main/java/com/example/emotune/decorator/Recommendation.java
package com.example.emotune.decorator;

import java.util.List;

public interface Recommendation {
    List<String> getSongs();
    String getDescription(); // for demo, can return emoji info or similar
}
