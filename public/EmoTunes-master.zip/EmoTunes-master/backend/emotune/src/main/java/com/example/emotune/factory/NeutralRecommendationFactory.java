package com.example.emotune.factory;

import com.example.emotune.service.music.MusicRecommender;
import com.example.emotune.service.music.SpotifyMusicAdapter;
import com.example.emotune.activity.ActivityRecommender;
import com.example.emotune.activity.NeutralActivityRecommender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("neutralRecommendationFactory")
public class NeutralRecommendationFactory implements EmotionRecommendationFactory {

    private final SpotifyMusicAdapter spotifyMusicAdapter;
    private final NeutralActivityRecommender neutralActivityRecommender;

    @Autowired
    public NeutralRecommendationFactory(SpotifyMusicAdapter spotifyMusicAdapter,
                                        NeutralActivityRecommender neutralActivityRecommender) {
        this.spotifyMusicAdapter = spotifyMusicAdapter;
        this.neutralActivityRecommender = neutralActivityRecommender;
    }

    @Override
    public MusicRecommender createMusicRecommender() {
        return spotifyMusicAdapter;
    }

    @Override
    public ActivityRecommender createActivityRecommender() {
        return neutralActivityRecommender;
    }
}
