package com.example.emotune.memento;

import java.util.Stack;

public class FeedbackCaretaker {
    private final Stack<FeedbackMemento> history = new Stack<>();

    public void saveState(FeedbackMemento memento) {
        history.push(memento);
    }

    public FeedbackMemento restoreState() {
        if (!history.isEmpty()) {
            return history.pop();
        }
        return null;
    }
}
