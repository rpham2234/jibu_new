// src/main/java/com/example/emotune/observer/FeedbackObserver.java
package com.example.emotune.observer;

import com.example.emotune.model.MusicFeedback;

public interface FeedbackObserver {
    void onFeedbackSubmitted(MusicFeedback feedback);
}
