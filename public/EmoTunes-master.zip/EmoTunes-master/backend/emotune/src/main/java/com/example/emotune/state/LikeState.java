package com.example.emotune.state;

public class LikeState implements FeedbackState {
    @Override
    public String handle(String feedback) {
        return "like".equalsIgnoreCase(feedback) ? "Positive" : "Neutral";
    }
}
