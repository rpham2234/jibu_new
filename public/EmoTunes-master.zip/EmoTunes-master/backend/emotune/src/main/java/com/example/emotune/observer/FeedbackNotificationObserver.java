// src/main/java/com/example/emotune/observer/FeedbackNotificationObserver.java
package com.example.emotune.observer;

import com.example.emotune.model.MusicFeedback;
import org.springframework.stereotype.Component;

@Component
public class FeedbackNotificationObserver implements FeedbackObserver {
    @Override
    public void onFeedbackSubmitted(MusicFeedback feedback) {
        // In real project: send notification/email/message
        System.out.println("Observer: FeedbackNotificationObserver - Feedback saved successfully for user " + feedback.getUserId());
    }
}
