package com.example.emotune.service.music;

import org.springframework.stereotype.Component;
import java.util.List;
import java.util.Map;

// This class is a Proxy for SpotifyMusicAdapter
@Component
public class SpotifyApiProxy implements MusicRecommender {

    private final SpotifyMusicAdapter spotifyAdapter;
    // You could add extra fields here for rate limit, cache, etc.

    public SpotifyApiProxy(SpotifyMusicAdapter spotifyAdapter) {
        this.spotifyAdapter = spotifyAdapter;
    }

    @Override
    public List<Map<String, String>> recommendMusic(String emotion) {
        // Example: add logging
        System.out.println("[Proxy] Intercepted request for emotion: " + emotion);

        // Call real adapter (now returns List<Map<String, String>>)
        List<Map<String, String>> songs = spotifyAdapter.recommendMusic(emotion);

        // Example: filter or modify result (optional)
        // if (songs.isEmpty()) System.out.println("[Proxy] No songs found");

        return songs;
    }
}
