package com.example.emotune.strategy;

import com.example.emotune.model.MusicFeedback;
import com.example.emotune.repository.MusicFeedbackRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PersonalizedRecommendationStrategy implements RecommendationStrategy {
    private final MusicFeedbackRepository feedbackRepo;

    public PersonalizedRecommendationStrategy(MusicFeedbackRepository feedbackRepo) {
        this.feedbackRepo = feedbackRepo;
    }

    @Override
    public List<String> recommend(Long userId, String emotion) {
        // Get liked songs for this user and emotion
        List<MusicFeedback> liked = feedbackRepo.findByUserIdAndEmotionAndFeedback(userId, emotion, "like");
        List<String> likedSongs = new ArrayList<>();
        for (MusicFeedback f : liked) likedSongs.add(f.getSongId());

        if (!likedSongs.isEmpty()) return likedSongs;

        // Get disliked songs to exclude
        List<MusicFeedback> disliked = feedbackRepo.findByUserIdAndEmotionAndFeedback(userId, emotion, "dislike");
        List<String> dislikedSongs = new ArrayList<>();
        for (MusicFeedback f : disliked) dislikedSongs.add(f.getSongId());

        // Fallback to all available songs for the emotion (simulate, you should fetch from song table/service)
        List<String> pool = getAllSongsForEmotion(emotion);
        pool.removeAll(dislikedSongs);

        return pool;
    }

    private List<String> getAllSongsForEmotion(String emotion) {
        // For demo, static songs. Replace with actual data source.
        if ("sad".equalsIgnoreCase(emotion))
            return new ArrayList<>(List.of("SongB", "SongC", "SongD"));
        if ("happy".equalsIgnoreCase(emotion))
            return new ArrayList<>(List.of("SongH", "SongI", "SongJ"));
        return new ArrayList<>(List.of("SongX", "SongY", "SongZ"));
    }
}
