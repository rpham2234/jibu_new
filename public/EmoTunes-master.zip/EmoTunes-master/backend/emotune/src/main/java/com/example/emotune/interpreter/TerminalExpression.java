package com.example.emotune.interpreter;

import com.example.emotune.model.MusicFeedback;
import java.util.List;
import java.util.stream.Collectors;

public class TerminalExpression implements InterpreterExpression {
    private final String field;
    private final String value;

    public TerminalExpression(String field, String value) {
        this.field = field;
        this.value = value;
    }

    @Override
    public List<MusicFeedback> interpret(List<MusicFeedback> feedbackList) {
        return feedbackList.stream()
                .filter(feedback -> {
                    switch (field.toLowerCase()) {
                        case "emotion": return value.equalsIgnoreCase(feedback.getEmotion());
                        case "feedback": return value.equalsIgnoreCase(feedback.getFeedback());
                        case "userid": return value.equals(String.valueOf(feedback.getUserId()));
                        case "songid": return value.equalsIgnoreCase(feedback.getSongId());
                        default: return false;
                    }
                })
                .collect(Collectors.toList());
    }
}
