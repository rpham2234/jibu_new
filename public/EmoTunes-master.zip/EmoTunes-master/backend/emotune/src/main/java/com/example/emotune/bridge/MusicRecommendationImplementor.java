package com.example.emotune.bridge;

import com.example.emotune.service.music.MusicRecommendationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class MusicRecommendationImplementor implements RecommendationImplementor {
    private final MusicRecommendationService musicService;

    @Autowired
    public MusicRecommendationImplementor(MusicRecommendationService musicService) {
        this.musicService = musicService;
    }

    @Override
    public List<String> recommend(Long userId, String emotion, String mode) {
        return musicService.recommend(userId, emotion, mode);
    }

    @Override
    public String getType() {
        return "Music";
    }
}
