package com.example.emotune.bridge;

import java.util.List;

public interface RecommendationImplementor {
    List<String> recommend(Long userId, String emotion, String mode);
    String getType();
}
