// src/main/java/com/example/emotune/repository/PlaylistRepository.java
package com.example.emotune.repository;

import com.example.emotune.model.Playlist;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PlaylistRepository extends JpaRepository<Playlist, Long> {
    List<Playlist> findByUserId(Long userId);
}
