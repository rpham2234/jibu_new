package com.example.emotune.config;

import com.example.emotune.service.music.SpotifyAuthService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SpotifyAuthInitializer {

    private final SpotifyAuthService spotifyAuthService;

    @Value("${spotify.client.id}")
    private String clientId;

    @Value("${spotify.client.secret}")
    private String clientSecret;

    public SpotifyAuthInitializer(SpotifyAuthService spotifyAuthService) {
        this.spotifyAuthService = spotifyAuthService;
    }

    @PostConstruct
    public void init() {
        spotifyAuthService.setConfig(clientId, clientSecret);
        System.out.println("SpotifyAuthService configured at startup!");
    }
}
