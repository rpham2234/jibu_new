package com.example.emotune.responses;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmotionResponse {
    private String emotion;
}
