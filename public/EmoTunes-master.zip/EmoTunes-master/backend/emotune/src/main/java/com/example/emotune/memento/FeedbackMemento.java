package com.example.emotune.memento;

import java.util.List;

public class FeedbackMemento {
    private final List<String> likedSongs;
    private final List<String> dislikedSongs;

    public FeedbackMemento(List<String> liked, List<String> disliked) {
        this.likedSongs = liked;
        this.dislikedSongs = disliked;
    }

    public List<String> getLikedSongs() {
        return likedSongs;
    }

    public List<String> getDislikedSongs() {
        return dislikedSongs;
    }
}
