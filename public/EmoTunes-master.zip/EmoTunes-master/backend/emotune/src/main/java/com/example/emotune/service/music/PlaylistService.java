// src/main/java/com/example/emotune/service/music/PlaylistService.java
package com.example.emotune.service.music;

import com.example.emotune.model.Playlist;
import com.example.emotune.repository.PlaylistRepository;
import com.example.emotune.builder.PlaylistBuilder;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PlaylistService {
    private final PlaylistRepository playlistRepository;
    public PlaylistService(PlaylistRepository playlistRepository) {
        this.playlistRepository = playlistRepository;
    }

    public Playlist createPlaylist(String name, Long userId, List<String> songIds) {
        PlaylistBuilder builder = new PlaylistBuilder()
                .setName(name)
                .setUserId(userId)
                .addSongs(songIds);
        Playlist playlist = builder.build();
        return playlistRepository.save(playlist);
    }

    public Playlist addSongToPlaylist(Long playlistId, String songId) {
        Playlist playlist = playlistRepository.findById(playlistId)
                .orElseThrow(() -> new RuntimeException("Playlist not found"));
        playlist.getSongIds().add(songId);
        return playlistRepository.save(playlist);
    }

    public List<Playlist> getPlaylistsForUser(Long userId) {
        return playlistRepository.findByUserId(userId);
    }

    public Playlist getPlaylist(Long playlistId) {
        return playlistRepository.findById(playlistId).orElse(null);
    }
}
