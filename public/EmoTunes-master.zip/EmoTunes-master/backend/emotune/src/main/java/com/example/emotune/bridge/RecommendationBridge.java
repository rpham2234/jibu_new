package com.example.emotune.bridge;

import java.util.List;

public abstract class RecommendationBridge {
    protected RecommendationImplementor implementor;

    public RecommendationBridge(RecommendationImplementor implementor) {
        this.implementor = implementor;
    }

    public abstract List<String> getRecommendations(Long userId, String emotion, String mode);

    // Optional: for display info
    public String getViewDescription() { return ""; }
}
