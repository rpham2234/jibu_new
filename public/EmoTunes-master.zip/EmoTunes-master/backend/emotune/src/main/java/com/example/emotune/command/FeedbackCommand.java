// src/main/java/com/example/emotune/command/FeedbackCommand.java
package com.example.emotune.command;

public interface FeedbackCommand {
    void execute();
}
