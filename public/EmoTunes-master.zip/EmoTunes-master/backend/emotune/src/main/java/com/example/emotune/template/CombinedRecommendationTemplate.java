package com.example.emotune.template;

import com.example.emotune.decorator.BasicRecommendation;
import com.example.emotune.decorator.CompositeRecommendation;
import com.example.emotune.decorator.EmojiRecommendationDecorator;
import com.example.emotune.decorator.Recommendation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CombinedRecommendationTemplate {

    public final ActivityRecommendationTemplate activityTemplate;
    public final MusicRecommendationTemplate musicTemplate;

    @Autowired
    public CombinedRecommendationTemplate(MusicRecommendationTemplate musicTemplate,
                                          ActivityRecommendationTemplate activityTemplate) {
        this.musicTemplate = musicTemplate;
        this.activityTemplate = activityTemplate;
    }

    public Recommendation recommendBundle(Long userId, String emotion, String mode) {
        List<String> musicList = musicTemplate.recommend(userId, emotion, mode);
        List<String> activityList = activityTemplate.recommend(userId, emotion, mode);

        // Each as a Recommendation (Leaf)
        BasicRecommendation baseMusic = new BasicRecommendation(musicList);
        Recommendation decoratedMusic = new EmojiRecommendationDecorator(baseMusic, emotion);
        BasicRecommendation activityRecs = new BasicRecommendation(activityList);

        // Create the composite
        CompositeRecommendation composite = new CompositeRecommendation();
        composite.add(decoratedMusic);      // Music branch
        composite.add(activityRecs);        // Activities branch

        return composite;
    }
}
