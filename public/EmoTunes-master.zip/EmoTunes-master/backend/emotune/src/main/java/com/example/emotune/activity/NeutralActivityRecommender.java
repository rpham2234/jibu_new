package com.example.emotune.activity;

import org.springframework.stereotype.Component;
import java.util.Arrays;
import java.util.List;

@Component
public class NeutralActivityRecommender implements ActivityRecommender {
    @Override
    public List<String> recommendActivity() {
        return Arrays.asList(
                "Read a book",
                "Practice mindfulness meditation",
                "Organize your workspace"
        );
    }
}
